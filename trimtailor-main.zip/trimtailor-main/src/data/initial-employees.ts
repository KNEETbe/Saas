
import { Employee } from '@/types/employee';

// Initial employee data
export const initialEmployees: Employee[] = [
  {
    id: "1",
    name: "Employee #1",
    position: "Employee",
    email: "employee1@example.com",
    phone: "+32 (0) 000 00 00 01",
    initials: "",
    categories: [
      { name: "Service", color: "white", backgroundColor: "#0EA5E9" },
      { name: "Service", color: "#16a34a", borderColor: "#16a34a", iconName: "check" },
    ]
  },
  {
    id: "2",
    name: "Employee #2",
    position: "Employee",
    email: "employee2@example.com",
    phone: "+32 (0) 000 00 00 02",
    initials: "",
    categories: [
      { name: "Service", color: "white", backgroundColor: "#F97316" },
      { name: "Service", color: "#d946ef", borderColor: "#d946ef", iconName: "check" },
    ],
    additionalCategories: 3
  },
  {
    id: "3",
    name: "Employee #3",
    position: "Employee",
    email: "employee3@example.com",
    phone: "+32 (0) 000 00 00 03",
    initials: "",
    categories: [
      { name: "Service", color: "white", backgroundColor: "#0EA5E9" },
      { name: "Service", color: "#f97316", borderColor: "#f97316", iconName: "check" },
    ]
  },
  {
    id: "4",
    name: "Employee #4",
    position: "Employee",
    email: "employee4@example.com",
    phone: "+32 (0) 000 00 00 04",
    initials: "AC",
    color: "#6366F1",
    categories: [
      { name: "Service", color: "#333", borderColor: "#e0e0e0" },
      { name: "Service", color: "white", backgroundColor: "#A855F7" },
    ]
  },
  {
    id: "5",
    name: "Employee #5",
    position: "Employee",
    email: "employee5@example.com",
    phone: "+32 (0) 000 00 00 05",
    initials: "PD",
    color: "#A3E635",
    categories: [
      { name: "Service", color: "#333", borderColor: "#f97316" },
      { name: "Service", color: "#f43f5e", borderColor: "#f43f5e", iconName: "check" },
    ]
  },
  {
    id: "6",
    name: "Employee #6",
    position: "Employee",
    email: "employee6@example.com",
    phone: "+32 (0) 000 00 00 06",
    initials: "",
    categories: [
      { name: "Service", color: "white", backgroundColor: "#F43F5E" },
    ]
  },
  {
    id: "7",
    name: "Employee #7",
    position: "Employee",
    email: "employee7@example.com",
    phone: "+32 (0) 000 00 00 07",
    initials: "",
    categories: [
      { name: "Service", color: "#333", borderColor: "#a855f7" },
      { name: "Service", color: "white", backgroundColor: "#F97316" },
    ]
  },
  {
    id: "8",
    name: "Employee #8",
    position: "Employee",
    email: "employee8@example.com",
    phone: "+32 (0) 000 00 00 08",
    initials: "",
    categories: [
      { name: "Service", color: "white", backgroundColor: "#0EA5E9" },
      { name: "Service", color: "white", backgroundColor: "#22C55E" },
    ]
  },
];
