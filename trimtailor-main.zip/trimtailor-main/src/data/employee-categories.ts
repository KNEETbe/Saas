
import { Category } from '@/types/employee';

// Color labels mapping
export const colorLabels: Record<string, string> = {
  "#0EA5E9": "Blue",
  "#22C55E": "Green",
  "#F97316": "Orange",
  "#A855F7": "Purple",
  "#F43F5E": "Red",
};

// Service categories data - using string identifiers for icons instead of JSX
export const serviceCategories: Category[] = [
  { id: "1", name: "Service", color: "#333", borderColor: "#e0e0e0" },
  { id: "2", name: "Service", color: "#16a34a", borderColor: "#16a34a", iconName: "check" },
  { id: "3", name: "Service", color: "white", backgroundColor: "#0ea5e9" },
  { id: "4", name: "Service", color: "#333", borderColor: "#e0e0e0" },
  { id: "5", name: "Service", color: "#16a34a", borderColor: "#16a34a", iconName: "check" },
  { id: "6", name: "Service", color: "white", backgroundColor: "#22c55e" },
  { id: "7", name: "Service", color: "#333", borderColor: "#f97316" },
  { id: "8", name: "Service", color: "#f97316", borderColor: "#f97316", iconName: "check" },
  { id: "9", name: "Service", color: "white", backgroundColor: "#f97316" },
  { id: "10", name: "Service", color: "#333", borderColor: "#a855f7" },
  { id: "11", name: "Service", color: "#d946ef", borderColor: "#d946ef", iconName: "check" },
  { id: "12", name: "Service", color: "white", backgroundColor: "#a855f7" },
  { id: "13", name: "Service", color: "#333", borderColor: "#f43f5e" },
  { id: "14", name: "Service", color: "#f43f5e", borderColor: "#f43f5e", iconName: "check" },
  { id: "15", name: "Service", color: "white", backgroundColor: "#f43f5e" },
];
