
import { useState } from "react";
import Sidebar from "@/components/dashboard/Sidebar";
import MainContent from "@/components/dashboard/MainContent";

const Dashboard = () => {
  const [salonName, setSalonName] = useState("Salon Naam");
  const [appointmentsCount, setAppointmentsCount] = useState(12);

  return (
    <div className="flex min-h-screen font-['Poppins',sans-serif] bg-[#f9fafb]">
      <Sidebar />
      <div className={`ml-[193px] transition-all duration-300 w-full`}>
        <MainContent salonName={salonName} appointmentsCount={appointmentsCount} />
      </div>
    </div>
  );
};

export default Dashboard;
