
import { useState } from "react";
import { useForm } from "react-hook-form";
import { Eye, EyeOff, RefreshCw, ArrowLeft } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useNavigate } from "react-router-dom";
import { useToast } from "@/hooks/use-toast";

interface ResetPasswordFormData {
  password: string;
  confirmPassword: string;
}

const ForgotPassword = () => {
  const { register, handleSubmit, formState: { errors }, getValues, setValue, watch } = useForm<ResetPasswordFormData>({
    defaultValues: {
      password: "",
      confirmPassword: ""
    }
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  const navigate = useNavigate();
  const { toast } = useToast();

  const generateRandomPassword = () => {
    const chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789!@#$%^&*()";
    let newPassword = "";
    for (let i = 0; i < 12; i++) {
      newPassword += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    setValue("password", newPassword);
    setValue("confirmPassword", newPassword);
  };

  const onSubmit = async (data: ResetPasswordFormData) => {
    if (data.password !== data.confirmPassword) {
      toast({
        title: "Passwords don't match",
        description: "Please make sure your passwords match.",
        variant: "destructive",
      });
      return;
    }

    setIsSubmitting(true);
    
    try {
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 1000));
      console.log("Password reset successful");
      
      toast({
        title: "Password reset successful",
        description: "You can now log in with your new password.",
      });
      
      // Redirect to login page
      navigate("/");
    } catch (error) {
      console.error("Error resetting password:", error);
      toast({
        title: "Error resetting password",
        description: "Please try again later.",
        variant: "destructive",
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <main className="min-h-screen flex flex-col items-center py-10 px-5 md:px-10 font-['Inter',sans-serif] bg-gradient-to-br from-purple-600 via-amber-500 to-pink-500">
      <div className="mb-10">
        <img 
          src="/lovable-uploads/c59ef76c-a67e-4043-8099-df183e8cc2a0.png" 
          alt="TrimTailor Logo" 
          className="h-8 object-contain"
        />
      </div>

      <div className="w-full max-w-[400px] mx-auto bg-white p-8 md:p-8 sm:p-6 rounded-lg shadow-md">
        <h1 className="text-xl font-semibold text-gray-900 mb-6">
          Fill in new password
        </h1>
        
        <form onSubmit={handleSubmit(onSubmit)} className="flex flex-col gap-4">
          <div className="flex flex-col gap-2">
            <label className="text-xs uppercase font-medium text-gray-500">
              PASSWORD
            </label>
            <div className="relative">
              <input
                {...register("password", { 
                  required: "Password is required",
                  minLength: {
                    value: 8,
                    message: "Password must be at least 8 characters"
                  }
                })}
                type={showPassword ? "text" : "password"}
                placeholder="Enter your password"
                className="w-full p-3 border border-gray-200 rounded-md text-sm focus:outline-none focus:ring-2 focus:ring-purple-500 focus:border-transparent"
              />
              <div className="absolute right-3 top-1/2 -translate-y-1/2 flex items-center gap-3 text-gray-500">
                <button 
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="focus:outline-none"
                >
                  {showPassword ? 
                    <EyeOff className="h-[18px] w-[18px]" /> : 
                    <Eye className="h-[18px] w-[18px]" />
                  }
                </button>
                <button 
                  type="button"
                  onClick={generateRandomPassword}
                  className="focus:outline-none"
                >
                  <RefreshCw className="h-[18px] w-[18px]" />
                </button>
              </div>
            </div>
            {errors.password && (
              <p className="text-red-500 text-xs mt-1">{errors.password.message}</p>
            )}
          </div>

          <div className="flex flex-col gap-2">
            <label className="text-xs uppercase font-medium text-gray-500">
              PASSWORD
            </label>
            <div className="relative">
              <input
                {...register("confirmPassword", { 
                  required: "Please confirm your password",
                  validate: value => value === getValues("password") || "Passwords do not match"
                })}
                type={showConfirmPassword ? "text" : "password"}
                placeholder="Confirm your password"
                className="w-full p-3 border border-gray-200 rounded-md text-sm focus:outline-none focus:ring-2 focus:ring-purple-500 focus:border-transparent"
              />
              <div className="absolute right-3 top-1/2 -translate-y-1/2 flex items-center gap-3 text-gray-500">
                <button 
                  type="button"
                  onClick={() => setShowConfirmPassword(!showConfirmPassword)}
                  className="focus:outline-none"
                >
                  {showConfirmPassword ? 
                    <EyeOff className="h-[18px] w-[18px]" /> : 
                    <Eye className="h-[18px] w-[18px]" />
                  }
                </button>
                <button 
                  type="button"
                  onClick={generateRandomPassword}
                  className="focus:outline-none"
                >
                  <RefreshCw className="h-[18px] w-[18px]" />
                </button>
              </div>
            </div>
            {errors.confirmPassword && (
              <p className="text-red-500 text-xs mt-1">{errors.confirmPassword.message}</p>
            )}
          </div>
          
          <button 
            type="submit" 
            className="bg-indigo-500 hover:bg-indigo-600 text-white border-none py-3 px-6 rounded-md font-medium cursor-pointer text-sm mt-2 transition-colors w-full"
            disabled={isSubmitting}
          >
            {isSubmitting ? "Resetting password..." : "Reset password"}
          </button>
        </form>
      </div>

      <div className="fixed bottom-5 right-5 text-white/80 text-xs">
        version: 1.0.0
      </div>
    </main>
  );
};

export default ForgotPassword;
