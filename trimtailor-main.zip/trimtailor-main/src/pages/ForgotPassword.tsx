import { useState } from "react";
import { useForm } from "react-hook-form";
import { ArrowLeft } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { useToast } from "@/hooks/use-toast";

interface ForgotPasswordFormData {
  email: string;
}

const ForgotPassword = () => {
  const { register, handleSubmit, formState: { errors } } = useForm<ForgotPasswordFormData>({
    defaultValues: {
      email: ""
    }
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const navigate = useNavigate();
  const { toast } = useToast();

  const onSubmit = async (data: ForgotPasswordFormData) => {
    setIsSubmitting(true);
    
    try {
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 1000));
      console.log("Password reset link sent to:", data.email);
      
      toast({
        title: "Reset link sent",
        description: "Check your email for a password reset link.",
      });
      
      // Navigate to email template page instead of reset password
      navigate("/email-template");
    } catch (error) {
      console.error("Error sending reset link:", error);
      toast({
        title: "Error sending reset link",
        description: "Please try again later.",
        variant: "destructive",
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleBackToLogin = () => {
    navigate("/");
  };

  return (
    <main className="min-h-screen flex flex-col items-center py-10 px-5 md:px-10 font-['Inter',sans-serif] bg-gradient-to-br from-purple-600 via-amber-500 to-pink-500">
      <div className="mb-10">
        <img 
          src="/lovable-uploads/c59ef76c-a67e-4043-8099-df183e8cc2a0.png" 
          alt="TrimTailor Logo" 
          className="h-8 object-contain"
        />
      </div>

      <div className="w-full max-w-[400px] mx-auto bg-white p-8 md:p-8 sm:p-6 rounded-lg shadow-md">
        <button
          onClick={handleBackToLogin}
          className="flex items-center text-gray-500 mb-6 hover:text-gray-700 transition-colors"
        >
          <ArrowLeft className="h-4 w-4 mr-1" />
          <span className="text-sm">Back to login</span>
        </button>
        
        <h1 className="text-xl font-semibold text-gray-900 mb-3">
          Forgot your password?
        </h1>
        
        <p className="text-gray-500 text-sm mb-6">
          Enter your email address and we'll send you a link to reset your password.
        </p>
        
        <form onSubmit={handleSubmit(onSubmit)} className="flex flex-col gap-4">
          <div className="flex flex-col gap-2">
            <label className="text-xs uppercase font-medium text-gray-500">
              EMAIL ADDRESS
            </label>
            <input
              {...register("email", { 
                required: "Email is required",
                pattern: {
                  value: /^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}$/i,
                  message: "Invalid email address"
                }
              })}
              type="email"
              placeholder="your@email.com"
              className="w-full p-3 border border-gray-200 rounded-md text-sm focus:outline-none focus:ring-2 focus:ring-purple-500 focus:border-transparent"
            />
            {errors.email && (
              <p className="text-red-500 text-xs mt-1">{errors.email.message}</p>
            )}
          </div>
          
          <button 
            type="submit" 
            className="bg-indigo-500 hover:bg-indigo-600 text-white border-none py-3 px-6 rounded-md font-medium cursor-pointer text-sm mt-2 transition-colors w-full"
            disabled={isSubmitting}
          >
            {isSubmitting ? "Sending reset link..." : "Send reset link"}
          </button>
        </form>
      </div>

      <div className="fixed bottom-5 right-5 text-white/80 text-xs">
        version: 1.0.0
      </div>
    </main>
  );
};

export default ForgotPassword;
