
import { useNavigate } from "react-router-dom";

const EmailTemplate = () => {
  const navigate = useNavigate();

  const handleResetClick = () => {
    navigate("/reset-password");
  };

  return (
    <div className="max-w-600px mx-auto p-10 font-['Inter',sans-serif] bg-white md:p-8 sm:p-6">
      <div className="mb-10">
        <img 
          src="/lovable-uploads/c59ef76c-a67e-4043-8099-df183e8cc2a0.png" 
          alt="TrimTailor Logo" 
          className="h-10 object-contain"
        />
      </div>

      <div className="mb-10">
        <div className="mb-15">
          <div className="text-2xl font-semibold text-gray-900 mb-4 sm:text-xl">
            Oops, looks like you forgot your password?
          </div>
          <div className="text-base text-gray-600 leading-relaxed mb-6 sm:text-sm">
            We received a request to reset your password. Click the link below to create a new one. 
            If you didn't make this request, simply ignore this email.
          </div>
          <button 
            onClick={handleResetClick}
            className="bg-amber-400 text-gray-900 border-none py-3 px-6 rounded-md font-medium cursor-pointer text-base sm:w-full"
          >
            Reset password
          </button>
        </div>

        <div>
          <div className="font-medium text-gray-900 mb-4">What's new?</div>
          <div className="flex gap-6 md:flex-col sm:gap-4">
            <div className="w-[200px] h-[140px] rounded-lg bg-gradient-to-br from-amber-100 to-amber-400 md:w-full md:h-40 sm:h-30"></div>
            <div className="flex-1">
              <div className="text-lg font-semibold text-gray-900 mb-3">
                Space for a feature launch and product visual
              </div>
              <div className="text-sm text-gray-500 leading-relaxed mb-4">
                Lorem ipsum dolor sit amet, consectetur adipiscing elit. Duis sit vehicula dui sit amet ligula cursus dolor sit amet dolor adipiscing.
              </div>
              <button className="bg-indigo-500 text-white border-none py-2 px-4 rounded-md text-sm cursor-pointer">
                Read more
              </button>
            </div>
          </div>
        </div>
      </div>

      <div className="flex justify-between items-center pt-10 border-t border-gray-200 sm:flex-col sm:gap-6 sm:text-center">
        <div className="flex items-center gap-1 text-gray-500 text-sm sm:justify-center">
          <div>© Trim Tailor -</div>
          <a href="https://www.trimtailor.com" className="text-gray-500 no-underline">
            www.trimtailor.com
          </a>
        </div>
        <div className="flex gap-4 sm:justify-center">
          <a href="#" className="text-gray-500 no-underline text-sm">Privacy</a>
          <a href="#" className="text-gray-500 no-underline text-sm">Account</a>
          <a href="#" className="text-gray-500 no-underline text-sm">Unsubscribe</a>
        </div>
        <div className="sm:order-first">
          <img 
            src="/lovable-uploads/c59ef76c-a67e-4043-8099-df183e8cc2a0.png" 
            alt="TrimTailor Logo" 
            className="h-8 object-contain"
          />
        </div>
      </div>
    </div>
  );
};

export default EmailTemplate;
