import { LoginForm } from "@/components/login/LoginForm";
import { LoginArt } from "@/components/login/LoginArt";
import { TipBox } from "@/components/login/TipBox";
import { VersionInfo } from "@/components/login/VersionInfo";

const Index = () => {
  return (
    <main className="bg-neutral-50 flex flex-col overflow-hidden items-stretch pt-10 pb-3.5 px-10 max-md:px-5">
      <div className="w-full max-md:max-w-full">
        <div className="gap-5 flex max-md:flex-col max-md:items-stretch">
          <section className="w-6/12 max-md:w-full max-md:ml-0">
            <div className="relative flex min-h-[653px] items-start gap-2.5 justify-center max-md:mt-10">
              <div className="bg-neutral-100 absolute z-0 flex min-w-60 min-h-[653px] overflow-hidden w-[652px] h-[653px] rounded-2xl right-0 bottom-0 max-md:max-w-full">
                <div className="flex min-h-[653px] min-w-60 w-full flex-1 shrink basis-[0%] rounded-[18px] max-md:max-w-full" />
              </div>
              <div className="z-0 min-w-60 w-[369px] my-auto">
                <LoginForm />
                <TipBox tip="This is a placeholder for Tips!" />
              </div>
            </div>
          </section>

          <section className="w-6/12 ml-5 max-md:w-full max-md:ml-0">
            <LoginArt />
          </section>
        </div>
      </div>
      <VersionInfo />
    </main>
  );
};

export default Index;
