
import React, { useState, useEffect } from 'react';
import { Settings, Pencil, Trash2, Plus } from 'lucide-react';
import VATRateModal from '@/components/VATRateModal';
import Sidebar from "@/components/dashboard/Sidebar";
import { useToast } from '@/hooks/use-toast';
import { Button } from '@/components/ui/button';

interface VATRate {
  id: number;
  name: string;
  percentage: string;
  dateAdded: string;
  lastModified: string;
}

const VATRates = () => {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isEditMode, setIsEditMode] = useState(false);
  const [currentRate, setCurrentRate] = useState<VATRate | null>(null);
  const { toast } = useToast();
  
  const [vatRates, setVatRates] = useState<VATRate[]>([
    { id: 1, name: 'Standard VAT', percentage: '21%', dateAdded: '15-10-2024', lastModified: '15-10-2024' },
    { id: 2, name: 'Reduced VAT', percentage: '6%', dateAdded: '15-10-2024', lastModified: '15-10-2024' },
  ]);

  const handleOpenModal = (rate?: VATRate) => {
    if (rate) {
      setCurrentRate(rate);
      setIsEditMode(true);
    } else {
      setCurrentRate(null);
      setIsEditMode(false);
    }
    setIsModalOpen(true);
  };

  const handleCloseModal = () => {
    setIsModalOpen(false);
    setCurrentRate(null);
    setIsEditMode(false);
  };

  const handleSaveVATRate = (name: string, percentage: string) => {
    const currentDate = new Date().toLocaleDateString('nl-NL', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric'
    }).replace(/\//g, '-');

    if (isEditMode && currentRate) {
      // Update existing VAT rate
      setVatRates(prevRates => 
        prevRates.map(rate => 
          rate.id === currentRate.id 
            ? { ...rate, name, percentage, lastModified: currentDate } 
            : rate
        )
      );
      toast({
        title: "Success",
        description: "VAT rate updated successfully",
      });
    } else {
      // Add new VAT rate
      const newVATRate = {
        id: vatRates.length > 0 ? Math.max(...vatRates.map(rate => rate.id)) + 1 : 1,
        name,
        percentage,
        dateAdded: currentDate,
        lastModified: currentDate,
      };
      setVatRates([...vatRates, newVATRate]);
      toast({
        title: "Success",
        description: "New VAT rate added successfully",
      });
    }
  };

  const handleDeleteVATRate = (id: number) => {
    setVatRates(prevRates => prevRates.filter(rate => rate.id !== id));
    toast({
      title: "Success",
      description: "VAT rate deleted successfully",
    });
  };

  return (
    <div className="flex min-h-screen font-['Poppins',sans-serif] bg-[#f9fafb]">
      <Sidebar />
      <div className="ml-[193px] transition-all duration-300 w-full">
        <div className="p-6">
          <div className="flex items-center gap-3 mb-6">
            <Settings className="text-[#312E81]" size={18} />
            <h1 className="text-[#030229] text-lg font-bold">VAT Rates</h1>
          </div>
          
          {/* VATRates Content */}
          <div className="bg-white rounded-lg border border-[rgba(217,218,222,0.3)] p-6">
            <div className="mb-4">
              <h2 className="text-[#030229] text-base font-semibold">List of VAT Rates</h2>
            </div>
            
            {/* Table content */}
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="text-left">
                    <th className="text-[#000] font-normal py-2 pl-12 text-xs">NO</th>
                    <th className="text-[#000] font-normal py-2 text-xs">VAT Name</th>
                    <th className="text-[#000] font-normal py-2 text-xs">Percentage</th>
                    <th className="text-[#000] font-normal py-2 text-xs">Date Added</th>
                    <th className="text-[#000] font-normal py-2 text-xs">Last Modified</th>
                    <th className="text-[#000] font-normal py-2 text-xs"></th>
                  </tr>
                </thead>
                <tbody>
                  {vatRates.map((rate, index) => (
                    <tr key={rate.id} className={`border-b border-[rgba(217,218,222,0.3)] ${index % 2 === 0 ? 'bg-[#f9fafb]' : ''}`}>
                      <td className="py-4 pl-12 text-[#000] text-xs">{rate.id}</td>
                      <td className="py-4 text-[#000] text-xs">{rate.name}</td>
                      <td className="py-4 text-[#000] text-xs">{rate.percentage}</td>
                      <td className="py-4 text-[#000] text-xs">{rate.dateAdded}</td>
                      <td className="py-4 text-[#000] text-xs">{rate.lastModified}</td>
                      <td className="py-4 text-right pr-6">
                        <div className="flex items-center gap-2 justify-end">
                          <button 
                            className="w-8 h-8 flex items-center justify-center rounded hover:bg-gray-100"
                            onClick={() => handleOpenModal(rate)}
                          >
                            <Pencil className="text-[#312E81]" size={15} />
                          </button>
                          <button 
                            className="w-8 h-8 flex items-center justify-center rounded bg-red-500 hover:bg-red-600"
                            onClick={() => handleDeleteVATRate(rate.id)}
                          >
                            <Trash2 className="text-white" size={15} />
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            {/* Action buttons */}
            <div className="flex justify-end gap-5 mt-5">
              <Button 
                onClick={() => handleOpenModal()} 
                className="bg-[#6366F1] text-white px-4 py-2 rounded-lg flex items-center gap-2 h-10"
              >
                <Plus size={16} />
                <span>Add VAT Rate</span>
              </Button>
              
              <Button className="bg-[rgba(99,102,241,0.5)] text-white px-8 py-2 rounded-lg h-10">
                Save
              </Button>
            </div>
          </div>
        </div>
      </div>
      
      {/* Modal */}
      {isModalOpen && (
        <VATRateModal 
          isOpen={isModalOpen} 
          onClose={handleCloseModal} 
          onSave={handleSaveVATRate}
          isEdit={isEditMode}
          vatRate={currentRate || undefined}
        />
      )}
    </div>
  );
};

export default VATRates;
