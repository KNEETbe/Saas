
import React, { useState } from 'react';
import Sidebar from '../components/dashboard/Sidebar';
import AddEmployeeModal from '../components/employees/AddEmployeeModal';
import EmployeesList from '../components/employees/EmployeesList';
import AddEmployeeButton from '../components/employees/AddEmployeeButton';
import EmployeeActions from '../components/employees/EmployeeActions';
import { useEmployees } from '../hooks/use-employees';
import { Employee, EmployeeData } from '@/types/employee';

const Employees = () => {
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [isEditModalOpen, setIsEditModalOpen] = useState(false);
  const [selectedEmployee, setSelectedEmployee] = useState<Employee | null>(null);

  const { 
    employees, 
    activeDropdown, 
    handleAddEmployee, 
    handleUpdateEmployee,
    handleDeleteEmployee, 
    handleDropdownToggle 
  } = useEmployees();

  const handleEditEmployee = (employee: Employee) => {
    setSelectedEmployee(employee);
    setIsEditModalOpen(true);
  };

  const handleCloseEditModal = () => {
    setIsEditModalOpen(false);
    setSelectedEmployee(null);
  };

  const handleSaveEdit = (updatedEmployeeData: EmployeeData) => {
    if (selectedEmployee) {
      handleUpdateEmployee(selectedEmployee.id, updatedEmployeeData);
    }
    handleCloseEditModal();
  };

  return (
    <div className="flex h-screen bg-[#FAFAFA]">
      <Sidebar />
      <div className="flex-1 overflow-auto ml-[193px]">
        <div className="px-8 py-6 w-full max-w-[1200px] mx-auto">
          <EmployeeActions />

          <EmployeesList 
            employees={employees}
            activeDropdown={activeDropdown}
            onDropdownToggle={handleDropdownToggle}
            onDeleteEmployee={handleDeleteEmployee}
            onEditEmployee={handleEditEmployee}
          />

          <AddEmployeeButton onClick={() => setIsAddModalOpen(true)} />
        </div>
      </div>
      
      {/* Add Employee Modal */}
      {isAddModalOpen && (
        <AddEmployeeModal 
          isOpen={isAddModalOpen} 
          onClose={() => setIsAddModalOpen(false)} 
          onSave={handleAddEmployee}
        />
      )}

      {/* Edit Employee Modal */}
      {isEditModalOpen && selectedEmployee && (
        <AddEmployeeModal 
          isOpen={isEditModalOpen}
          onClose={handleCloseEditModal}
          onSave={handleSaveEdit}
          employee={selectedEmployee}
          isEditing={true}
        />
      )}
    </div>
  );
};

export default Employees;
