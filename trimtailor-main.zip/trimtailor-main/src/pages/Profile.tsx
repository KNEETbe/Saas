import { Button } from "@/components/ui/button";
import { ArrowLeft, Settings, Upload } from "lucide-react";
import { Link, useNavigate } from "react-router-dom";

const Profile = () => {
  const navigate = useNavigate();

  const handleGoBack = () => {
    navigate(-1); // Navigeer terug naar het vorige scherm
  };

  return (
    <div className="ml-[193px] bg-[#F5F5F5] min-h-screen">
      <div className="p-10 max-w-[1039px] mx-auto font-['Poppins',sans-serif]">
        {/* Header with Back Button */}
        <div className="flex flex-col gap-10 mb-25">
          <div className="flex items-center gap-3">
            <Button 
              variant="ghost" 
              size="icon" 
              onClick={handleGoBack} 
              className="mr-2 text-[#312E81]"
            >
              <ArrowLeft size={24} />
            </Button>
            <Settings size={24} className="text-[#312E81]" />
            <span className="text-base font-semibold text-[#262626]">Profile</span>
          </div>
          <div className="pl-5">
            <div className="text-xs text-[#262626] uppercase">Plan: Free Trial</div>
            <div className="text-xs text-[#262626] uppercase">End date: 31-12-2024</div>
          </div>
        </div>

        {/* Company Profile */}
        <div className="bg-white rounded-[10px] border border-[rgba(217,218,222,0.3)] p-6 mb-6">
          <div className="text-base font-bold text-[#262626] mb-3">Company profile</div>
          
          <div className="grid grid-cols-3 gap-4 md:grid-cols-2 sm:grid-cols-1">
            {/* Company Name */}
            <div className="flex flex-col gap-2">
              <label className="text-xs text-[#262626] uppercase">
                Company name <span className="text-[#F87171] ml-1">*</span>
              </label>
              <input 
                type="text" 
                placeholder="Fill in placeholder" 
                className="h-10 px-3 py-4 rounded border-none bg-[#F5F5F5] text-xs text-[#262626]"
              />
            </div>

            {/* Email */}
            <div className="flex flex-col gap-2">
              <label className="text-xs text-[#262626] uppercase">
                Email <span className="text-[#F87171] ml-1">*</span>
              </label>
              <input 
                type="email" 
                value="info@example.be" 
                className="h-10 px-3 py-4 rounded border-none bg-[#F5F5F5] text-xs text-[#262626]"
              />
            </div>

            {/* Phone Number */}
            <div className="flex flex-col gap-2">
              <label className="text-xs text-[#262626] uppercase">
                Phone number <span className="text-[#F87171] ml-1">*</span>
              </label>
              <input 
                type="tel" 
                value="+32 (0) 000 00 00 00" 
                className="h-10 px-3 py-4 rounded border-none bg-[#F5F5F5] text-xs text-[#262626]"
              />
            </div>

            {/* Street Address */}
            <div className="flex flex-col gap-2">
              <label className="text-xs text-[#262626] uppercase">
                Street address <span className="text-[#F87171] ml-1">*</span>
              </label>
              <input 
                type="text" 
                placeholder="Fill in placeholder" 
                className="h-10 px-3 py-4 rounded border-none bg-[#F5F5F5] text-xs text-[#262626]"
              />
            </div>

            {/* City */}
            <div className="flex flex-col gap-2">
              <label className="text-xs text-[#262626] uppercase">
                City <span className="text-[#F87171] ml-1">*</span>
              </label>
              <input 
                type="text" 
                value="Brussels" 
                className="h-10 px-3 py-4 rounded border-none bg-[#F5F5F5] text-xs text-[#262626]"
              />
            </div>

            {/* Zip */}
            <div className="flex flex-col gap-2">
              <label className="text-xs text-[#262626] uppercase">
                Zip <span className="text-[#F87171] ml-1">*</span>
              </label>
              <input 
                type="text" 
                value="1000" 
                className="h-10 px-3 py-4 rounded border-none bg-[#F5F5F5] text-xs text-[#262626]"
              />
            </div>
          </div>

          {/* Client Logo */}
          <div className="mt-4">
            <div className="text-sm text-[#262626]">Client Logo</div>
            <button className="w-full h-10 border border-[#312E81] rounded-lg bg-white text-[#312E81] font-medium flex items-center justify-center gap-3 mt-2.5 cursor-pointer">
              <Upload size={16} />
              <span>Upload Logo</span>
            </button>
          </div>
        </div>

        {/* Settings row */}
        <div className="flex gap-6 md:flex-col sm:flex-col">
          {/* Business Timing */}
          <div className="bg-white rounded-[10px] border border-[rgba(217,218,222,0.3)] p-6 mb-6 w-[232.67px] md:w-full sm:w-full">
            <div className="text-base font-bold text-[#262626] mb-3">Business timing</div>
            
            <div className="flex flex-col gap-2">
              <label className="text-xs text-[#262626] uppercase">Start time</label>
              <select className="h-10 px-3 py-4 rounded border-none bg-[#F5F5F5] text-xs text-[#262626]">
                <option>09:00</option>
                <option>08:00</option>
                <option>10:00</option>
              </select>
            </div>

            <div className="flex flex-col gap-2 mt-2">
              <label className="text-xs text-[#262626] uppercase">End time</label>
              <select className="h-10 px-3 py-4 rounded border-none bg-[#F5F5F5] text-xs text-[#262626]">
                <option>17:00</option>
                <option>16:00</option>
                <option>18:00</option>
              </select>
            </div>
          </div>

          {/* General Settings */}
          <div className="bg-white rounded-[10px] border border-[rgba(217,218,222,0.3)] p-6 mb-6 flex-1">
            <div className="text-base font-bold text-[#262626] mb-3">General settings</div>
            
            <div className="flex flex-col gap-6">
              <div className="flex flex-col gap-2">
                <label className="text-xs text-[#262626] uppercase">Language</label>
                <select className="h-10 px-3 py-4 rounded border-none bg-[#F5F5F5] text-xs text-[#262626]">
                  <option>🇬🇧 English</option>
                  <option>🇧🇪 Dutch</option>
                  <option>🇧🇪 French</option>
                </select>
              </div>

              <div className="flex flex-col gap-2">
                <label className="text-xs text-[#262626] uppercase">Currency</label>
                <select className="h-10 px-3 py-4 rounded border-none bg-[#F5F5F5] text-xs text-[#262626]">
                  <option>€ EUR</option>
                  <option>$ USD</option>
                  <option>£ GBP</option>
                </select>
              </div>

              <div className="flex flex-col gap-2">
                <label className="text-xs text-[#262626] uppercase">Time zone</label>
                <select className="h-10 px-3 py-4 rounded border-none bg-[#F5F5F5] text-xs text-[#262626]">
                  <option>UTC+01:00</option>
                  <option>UTC+00:00</option>
                  <option>UTC+02:00</option>
                </select>
              </div>

              {/* Week Start */}
              <div>
                <label className="text-xs text-[#262626] uppercase">Week start</label>
                <div className="flex gap-5 mt-2">
                  <div className="flex items-center gap-3">
                    <input 
                      type="checkbox" 
                      checked 
                      className="h-4 w-4 rounded bg-[#EEF2FF] border-[#6366F1] text-[#312E81]" 
                    />
                    <span className="text-xs text-[#262626]">Monday</span>
                  </div>
                  <div className="flex items-center gap-3">
                    <input 
                      type="checkbox" 
                      className="h-4 w-4 rounded border-[#6366F1] bg-[#F5F5F5]" 
                    />
                    <span className="text-xs text-[#262626]">Sunday</span>
                  </div>
                </div>
              </div>

              {/* Time Format */}
              <div>
                <label className="text-xs text-[#262626] uppercase">Time Format</label>
                <div className="flex gap-5 mt-2">
                  <div className="flex items-center gap-3">
                    <input 
                      type="checkbox" 
                      checked 
                      className="h-4 w-4 rounded bg-[#EEF2FF] border-[#6366F1] text-[#312E81]" 
                    />
                    <span className="text-xs text-[#262626]">13:15</span>
                  </div>
                  <div className="flex items-center gap-3">
                    <input 
                      type="checkbox" 
                      className="h-4 w-4 rounded border-[#6366F1] bg-[#F5F5F5]" 
                    />
                    <span className="text-xs text-[#262626]">1:15 PM</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Notification and Login Image row */}
        <div className="flex gap-6 md:flex-col sm:flex-col">
          {/* Notification Sending */}
          <div className="bg-white rounded-[10px] border border-[rgba(217,218,222,0.3)] p-6 mb-6 flex-1">
            <div className="text-base font-bold text-[#262626] mb-3">Notification sending</div>
            
            <div className="grid grid-cols-3 gap-4 md:grid-cols-2 sm:grid-cols-1">
              <div className="flex flex-col gap-2">
                <label className="text-xs text-[#262626] uppercase">Notification email address</label>
                <input 
                  type="email" 
                  value="info@example.com" 
                  className="h-10 px-3 py-4 rounded border-none bg-[#F5F5F5] text-xs text-[#262626]"
                />
              </div>

              <div className="flex flex-col gap-2">
                <label className="text-xs text-[#262626] uppercase">Billing email address</label>
                <input 
                  type="email" 
                  value="info@example.com" 
                  className="h-10 px-3 py-4 rounded border-none bg-[#F5F5F5] text-xs text-[#262626]"
                />
              </div>

              <div className="flex flex-col gap-2">
                <label className="text-xs text-[#262626] uppercase">SMS message sender</label>
                <input 
                  type="tel" 
                  value="+32 (0) 000 00 00 00" 
                  className="h-10 px-3 py-4 rounded border-none bg-[#F5F5F5] text-xs text-[#262626]"
                />
              </div>

              <div className="flex flex-col gap-2">
                <label className="text-xs text-[#262626] uppercase">City</label>
                <input 
                  type="text" 
                  value="Brussels" 
                  className="h-10 px-3 py-4 rounded border-none bg-[#F5F5F5] text-xs text-[#262626]"
                />
              </div>
            </div>
          </div>

          {/* Login Screen Image */}
          <div className="bg-white rounded-[10px] border border-[rgba(217,218,222,0.3)] p-6 mb-6 w-[233px] md:w-full sm:w-full">
            <div className="text-base font-bold text-[#262626] mb-3">Login screen image</div>
            
            <div>
              <div className="h-[82px] border border-[#D9DADE] rounded-lg bg-[rgba(220,220,222,0.1)]"></div>
              <button className="w-full h-10 border border-[#312E81] rounded-lg bg-white text-[#312E81] font-medium flex items-center justify-center gap-3 mt-2.5 cursor-pointer">
                <Upload size={16} />
                <span>Upload Image</span>
              </button>
            </div>
          </div>
        </div>

        {/* Save Button */}
        <div className="flex justify-end mt-6">
          <Button className="w-[108px] h-10 bg-[#6366F1] text-white text-sm">Save</Button>
        </div>
      </div>
    </div>
  );
};

export default Profile;
