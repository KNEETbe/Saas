
import React, { useState } from 'react';
import Sidebar from '../components/dashboard/Sidebar';
import EmailSection from '../components/mail/EmailSection';
import EmailLog from '../components/mail/EmailLog';

const Mail = () => {
  const beforeAppointmentSettings = [
    { label: 'Confirmation', description: 'Send confirmation mails to client', active: true },
    { label: 'Confirmation (recurring)', description: 'Recurring appointment confirmations', active: true },
    { label: 'Reminder', description: 'Remind clients about upcoming appointments', active: true },
    { label: 'Request confirmation', description: 'Ask clients to confirm appointments', active: true },
    { label: 'Request rejected', description: 'Notifications when requests are rejected', active: true }
  ];

  const appointmentChangeSettings = [
    { label: 'Rescheduled', description: 'Notify about appointment reschedules', active: false },
    { label: 'Rescheduled (recurring)', description: 'Notify about recurring changes', active: false },
    { label: 'Cancelled', description: 'Notify when appointments are cancelled', active: false },
    { label: 'No-show', description: 'Notify about missed appointments', active: false }
  ];

  const afterAppointmentSettings = [
    { label: 'Digital invoice', description: 'Send digital invoices after appointments', active: false },
    { label: 'Confirmation', description: 'Confirm appointment completion', active: false },
    { label: 'Request feedback', description: 'Ask clients for feedback', active: false }
  ];

  return (
    <div className="flex h-screen bg-[#FAFAFA]">
      <Sidebar />
      <div className="flex-1 overflow-auto ml-[193px]">
        <div className="flex flex-col max-w-[1138px] mx-auto p-5 gap-8">
          <div className="flex flex-col items-start gap-3">
            <svg width="60" height="24" viewBox="0 0 60 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <path d="M14.7595 9.98778C14.974 9.7951 15.0579 9.49366 14.9584 9.22329C14.8217 8.85348 14.657 8.4992 14.4674 8.15736L14.3214 7.90563C14.1162 7.56379 13.8863 7.24059 13.6346 6.93604C13.4512 6.71229 13.1467 6.6377 12.8732 6.72472L11.6363 7.11628C11.3256 7.21573 10.9899 7.15047 10.7133 6.97333C10.5611 6.87699 10.4057 6.78376 10.2441 6.70296C9.95507 6.55379 9.73131 6.29275 9.65984 5.97577L9.38325 4.71094C9.3211 4.42814 9.10356 4.20439 8.81766 4.15777C8.3919 4.08319 7.95061 4.0459 7.5 4.0459C7.04939 4.0459 6.6081 4.08319 6.17924 4.15467C5.89333 4.20128 5.67579 4.42504 5.61364 4.70783L5.33706 5.97266C5.26869 6.28964 5.04183 6.55069 4.75281 6.69986C4.59121 6.78376 4.43583 6.87389 4.28355 6.97022C4.01008 7.14736 3.67134 7.20951 3.36057 7.11318L2.12682 6.72161C1.85335 6.63459 1.5488 6.71229 1.36544 6.93293C1.11372 7.23748 0.883754 7.56068 0.678647 7.90253L0.532586 8.15425C0.343018 8.49609 0.178311 8.85037 0.0415732 9.22018C-0.0578725 9.49055 0.0260348 9.792 0.240465 9.98467L1.20074 10.8579C1.44003 11.0786 1.55501 11.4018 1.53947 11.725C1.53637 11.8151 1.53326 11.9052 1.53326 11.9984C1.53326 12.0917 1.53637 12.1818 1.53947 12.2719C1.55501 12.5982 1.44314 12.9214 1.20074 13.139L0.240465 14.0153C0.0260348 14.208 -0.0578725 14.5094 0.0415732 14.7798C0.178311 15.1496 0.343018 15.5039 0.532586 15.8458L0.678647 16.0975C0.883754 16.4393 1.11372 16.7625 1.36544 17.0671C1.5488 17.2908 1.85335 17.3654 2.12682 17.2784L3.36057 16.8868C3.67134 16.7874 4.00697 16.8526 4.28355 17.0298C4.43583 17.1261 4.59121 17.2193 4.75281 17.3001C5.04183 17.4493 5.26558 17.7104 5.33706 18.0273L5.61364 19.2922C5.67579 19.575 5.89333 19.7987 6.17924 19.8453C6.6081 19.9168 7.04939 19.9541 7.5 19.9541C7.95061 19.9541 8.3919 19.9168 8.82076 19.8453C9.10667 19.7987 9.32421 19.575 9.38636 19.2922L9.66294 18.0273C9.73131 17.7104 9.95507 17.4493 10.2472 17.3001C10.4088 17.2162 10.5642 17.1261 10.7164 17.0298C10.9899 16.8526 11.3287 16.7905 11.6394 16.8868L12.8732 17.2784C13.1467 17.3654 13.4512 17.2877 13.6346 17.0671C13.8863 16.7625 14.1162 16.4393 14.3214 16.0975L14.4674 15.8458C14.657 15.5039 14.8186 15.1496 14.9584 14.7798C15.0579 14.5094 14.974 14.208 14.7595 14.0153L13.7993 13.1421C13.56 12.9214 13.445 12.5982 13.4605 12.275C13.4636 12.1849 13.4667 12.0948 13.4667 12.0016C13.4667 11.9083 13.4636 11.8182 13.4605 11.7281C13.445 11.4018 13.5569 11.0786 13.7993 10.861L14.7595 9.98778ZM7.5 9.01818C8.29124 9.01818 9.05007 9.3325 9.60956 9.89199C10.1691 10.4515 10.4834 11.2103 10.4834 12.0016C10.4834 12.7928 10.1691 13.5516 9.60956 14.1111C9.05007 14.6706 8.29124 14.9849 7.5 14.9849C6.70876 14.9849 5.94993 14.6706 5.39044 14.1111C4.83095 13.5516 4.51663 12.7928 4.51663 12.0016C4.51663 11.2103 4.83095 10.4515 5.39044 9.89199C5.94993 9.3325 6.70876 9.01818 7.5 9.01818Z" fill="#4A4CA0"/>
              <path opacity="0.4" d="M5.51123 12.0016C5.51123 11.4741 5.72078 10.9682 6.09377 10.5952C6.46676 10.2222 6.97265 10.0127 7.50014 10.0127C8.02764 10.0127 8.53352 10.2222 8.90652 10.5952C9.27951 10.9682 9.48906 11.4741 9.48906 12.0016C9.48906 12.5291 9.27951 13.035 8.90652 13.408C8.53352 13.781 8.02764 13.9905 7.50014 13.9905C6.97265 13.9905 6.46676 13.781 6.09377 13.408C5.72078 13.035 5.51123 12.5291 5.51123 12.0016Z" fill="#4A4CA0"/>
              <text fill="#030229" style={{whiteSpace: 'pre'}} fontFamily="Poppins" fontSize="16" fontWeight="600" letterSpacing="0em">
                <tspan x="25" y="17.6">Mail</tspan>
              </text>
            </svg>
          </div>

          <EmailSection 
            title="Email list"
            description="Notify your employees and clients about their appointments via email."
            settings={beforeAppointmentSettings}
          />

          <EmailSection 
            title="Appointment change"
            description="Email notifications for appointment changes."
            settings={appointmentChangeSettings}
          />

          <EmailSection 
            title="After appointment"
            description="Email notifications after appointments."
            settings={afterAppointmentSettings}
          />

          <EmailLog />
        </div>
      </div>
    </div>
  );
};

export default Mail;
