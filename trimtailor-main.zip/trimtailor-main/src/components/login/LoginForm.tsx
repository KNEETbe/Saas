
import { useState } from "react";
import { useForm } from "react-hook-form";
import { Eye, EyeOff } from "lucide-react";
import { useNavigate } from "react-router-dom";

interface LoginFormData {
  email: string;
  password: string;
  captcha: boolean;
}

export const LoginForm = () => {
  const [showPassword, setShowPassword] = useState(false);
  const { register, handleSubmit } = useForm<LoginFormData>();
  const navigate = useNavigate();

  const onSubmit = (data: LoginFormData) => {
    console.log(data);
    // Navigeer naar de dashboard pagina na inloggen
    navigate("/dashboard");
  };

  return (
    <div className="flex w-full flex-col items-stretch">
      <div className="self-center flex min-h-14 gap-2.5 justify-center">
        <img 
          src="/lovable-uploads/c59ef76c-a67e-4043-8099-df183e8cc2a0.png" 
          alt="TrimTailor Logo" 
          className="h-10 object-contain"
        />
      </div>
      <div className="bg-white flex w-full gap-2.5 mt-8 p-10 rounded-xl max-md:px-5">
        <div className="min-w-60 w-full flex-1 shrink basis-[0%]">
          <div className="flex w-full flex-col text-[21px] text-[#0C1421] font-semibold text-center tracking-[0.21px] leading-none">
            <h1>Sign in to your account</h1>
          </div>
          
          <form
            onSubmit={handleSubmit(onSubmit)}
            className="flex w-full flex-col items-stretch justify-center mt-5"
          >
            <div className="flex w-full flex-col items-stretch text-xs font-normal whitespace-nowrap">
              <label className="flex gap-[3px] uppercase">
                <span className="text-neutral-800">EMAIL</span>
                <span className="text-red-400">*</span>
              </label>
              <input
                {...register("email")}
                type="email"
                placeholder="Example@email.com"
                className="self-stretch bg-neutral-100 min-h-10 w-full text-neutral-800 mt-[7px] px-3 py-[11px] rounded-[5px]"
              />
            </div>

            <div className="w-full mt-[18px]">
              <div className="flex w-full items-center gap-[40px_100px] text-xs font-normal justify-between">
                <label className="self-stretch flex gap-[3px] whitespace-nowrap uppercase my-auto">
                  <span className="text-neutral-800">PASSWORD</span>
                  <span className="text-red-400">*</span>
                </label>
                <button
                  type="button"
                  onClick={() => navigate("/forgot-password")}
                  className="text-[#1E4AE9] text-center leading-none tracking-[0.12px] self-stretch my-auto"
                >
                  Forgot Password?
                </button>
              </div>
              <div className="bg-neutral-100 flex min-h-10 w-full items-center gap-[40px_100px] justify-between mt-[7px] px-3 py-[11px] rounded-[5px]">
                <input
                  {...register("password")}
                  type={showPassword ? "text" : "password"}
                  placeholder="Enter your password"
                  className="bg-transparent border-none outline-none w-full text-xs"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="focus:outline-none"
                >
                  {showPassword ? (
                    <EyeOff className="h-4 w-4 text-gray-500" />
                  ) : (
                    <Eye className="h-4 w-4 text-gray-500" />
                  )}
                </button>
              </div>
            </div>

            <div className="bg-neutral-50 border flex w-[213px] max-w-full items-center gap-2 font-normal mt-[18px] px-3 py-[11px] border-[rgba(224,224,224,1)] border-solid">
              <input
                type="checkbox"
                {...register("captcha")}
                className="bg-white self-stretch w-[17px] h-[17px] my-auto rounded-[3px] border-[rgba(219,219,219,1)] border-solid border-2"
              />
              <span className="text-[rgba(29,31,32,1)] text-[10px] self-stretch my-auto">
                Verify you are human
              </span>
              <div className="self-stretch flex flex-col items-stretch text-[6px] text-black text-right">
                <img
                  src="https://cdn.builder.io/api/v1/image/assets/TEMP/aaf2ae7d6acc365081ba1c8de52cac830a287ae4a9aa337ccf2395d91b53a631?placeholderIfAbsent=true"
                  className="aspect-[2.94] object-contain w-[53px]"
                  alt="Captcha"
                />
                <div className="ml-2.5">Privacy • Terms</div>
              </div>
            </div>

            <button
              type="submit"
              className="w-full text-sm text-white font-medium text-center mt-[18px] bg-indigo-500 min-h-10 px-4 py-[9px] rounded-lg hover:bg-indigo-600 transition-colors"
            >
              Log in
            </button>
          </form>
        </div>
      </div>
    </div>
  );
};
