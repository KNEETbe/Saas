export const VersionInfo = () => {
  return (
    <div className="text-xs text-neutral-800 font-normal mt-2 pl-[5px] max-md:mr-1">
      <div className="flex items-center gap-3">
        <div className="self-stretch my-auto">version: 1.0.0</div>
      </div>
    </div>
  );
};
