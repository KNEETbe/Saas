interface TipBoxProps {
  tip: string;
}

export const TipBox = ({ tip }: TipBoxProps) => {
  return (
    <div className="bg-white flex w-full items-center gap-2.5 text-xs text-[#030229] font-light mt-5 px-6 py-4 rounded-xl max-md:px-5">
      <div className="self-stretch min-w-60 w-full flex-1 shrink basis-[0%] my-auto">
        <span className="font-bold">Tip: </span>
        {tip}
      </div>
    </div>
  );
};
