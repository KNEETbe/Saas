export const LoginArt = () => {
  return (
    <div className="relative min-h-[653px] grow rounded-2xl max-md:mt-10">
      <img
        src="https://cdn.builder.io/api/v1/image/assets/TEMP/9404f97784900d06aa009c58f824ad7f0530619a212a56fa74416544e66affb5?placeholderIfAbsent=true"
        className="absolute h-full w-full object-cover inset-0 rounded-2xl"
        alt="Login artwork"
      />
      <div className="relative flex min-h-[653px] min-w-60 w-full flex-1 shrink basis-[0%] rounded-[18px] max-md:max-w-full" />
    </div>
  );
};
