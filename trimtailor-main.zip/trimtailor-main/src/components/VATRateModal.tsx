
import React, { useState, useEffect } from 'react';
import { X } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useToast } from '@/hooks/use-toast';

interface VATRate {
  id: number;
  name: string;
  percentage: string;
  dateAdded: string;
  lastModified: string;
}

interface VATRateModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (name: string, percentage: string) => void;
  isEdit?: boolean;
  vatRate?: VATRate;
}

const VATRateModal: React.FC<VATRateModalProps> = ({ 
  isOpen, 
  onClose, 
  onSave, 
  isEdit = false,
  vatRate 
}) => {
  const [name, setName] = useState('');
  const [percentage, setPercentage] = useState('');
  const { toast } = useToast();

  useEffect(() => {
    if (isEdit && vatRate) {
      setName(vatRate.name);
      setPercentage(vatRate.percentage);
    }
  }, [isEdit, vatRate]);

  if (!isOpen) return null;

  const handleSubmit = () => {
    if (!name || !percentage) {
      toast({
        title: "Error",
        description: "Please fill in all fields",
        variant: "destructive",
      });
      return;
    }
    
    // Make sure percentage has % symbol
    const formattedPercentage = percentage.includes('%') 
      ? percentage 
      : `${percentage}%`;
    
    onSave(name, formattedPercentage);
    setName('');
    setPercentage('');
    onClose();
  };

  return (
    <div className="fixed inset-0 flex justify-center items-center min-h-screen bg-black/10 z-50">
      <div className="w-[431px] bg-white rounded-[10px] shadow-md p-[16px_24px_24px] max-w-full md:w-[90%] sm:p-[12px_16px_16px]">
        <div className="flex justify-between items-center mb-8">
          <div className="text-[#262626] font-['Poppins',sans-serif] text-[20.7px] font-semibold">
            {isEdit ? 'Edit VAT Rate' : 'Add VAT Rate'}
          </div>
          <X 
            className="w-4 h-4 text-[#9A98A1] cursor-pointer" 
            onClick={onClose}
          />
        </div>
        
        <div className="flex w-full items-center gap-2 mb-10 sm:flex-col">
          <div className="flex flex-col gap-[7px] flex-1 w-full">
            <label className="text-[#030229] font-['Poppins',sans-serif] text-xs font-normal">
              VAT Rate Name
            </label>
            <input
              type="text"
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="Enter name"
              className="flex h-[33px] px-3 py-4 items-center rounded-[5px] bg-[#F5F5F5] text-[#030229] font-['Poppins',sans-serif] text-xs"
            />
          </div>
          
          <div className="flex flex-col gap-[7px] flex-1 w-full">
            <label className="text-[#030229] font-['Poppins',sans-serif] text-xs font-normal">
              VAT Percentage
            </label>
            <input
              type="text"
              value={percentage}
              onChange={(e) => setPercentage(e.target.value)}
              placeholder="XX %"
              className="flex h-[33px] px-3 py-4 items-center rounded-[5px] bg-[#F7F7F8] text-[#030229] font-['Poppins',sans-serif] text-xs"
            />
          </div>
        </div>
        
        <div className="flex justify-end gap-[14px] sm:flex-col-reverse">
          <Button 
            className="rounded-lg border border-[#6366F1] bg-transparent text-[#6366F1] font-['Poppins',sans-serif] text-sm font-normal sm:w-full"
            onClick={onClose}
          >
            Close
          </Button>
          <Button 
            className="rounded-lg bg-[#6366F1] border-none text-white font-['Poppins',sans-serif] text-sm font-normal sm:w-full"
            onClick={handleSubmit}
          >
            {isEdit ? 'Update VAT Rate' : 'Create VAT Rate'}
          </Button>
        </div>
      </div>
    </div>
  );
};

export default VATRateModal;
