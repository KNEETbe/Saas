
import React from 'react';
import { Plus } from 'lucide-react';
import { Button } from '@/components/ui/button';

interface AddEmployeeButtonProps {
  onClick: () => void;
}

const AddEmployeeButton: React.FC<AddEmployeeButtonProps> = ({ onClick }) => {
  return (
    <div className="fixed bottom-6 right-6">
      <Button
        className="bg-[#635BFE] hover:bg-[#4F46E5] rounded-full h-12 px-5 shadow-md"
        onClick={onClick}
      >
        <Plus size={18} className="mr-2" />
        Add Employee
      </Button>
    </div>
  );
};

export default AddEmployeeButton;
