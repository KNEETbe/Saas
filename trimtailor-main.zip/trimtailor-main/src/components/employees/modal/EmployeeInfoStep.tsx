
import React from 'react';
import EmployeeBasicInfo from '../form/EmployeeBasicInfo';
import EmployeeOptions from '../form/EmployeeOptions';
import CategorySelector from '../form/CategorySelector';
import { serviceCategories } from '@/data/employee-categories';
import { StepProps } from './EmployeeModalTypes';

const EmployeeInfoStep: React.FC<StepProps> = ({
  employeeData,
  onInputChange,
  onCheckboxChange,
  onCategorySelect,
  onColorSelect
}) => {
  return (
    <div className="space-y-6">
      <EmployeeBasicInfo 
        name={employeeData.name}
        email={employeeData.email}
        gender={employeeData.gender || ''}
        phone={employeeData.phone}
        color={employeeData.color || ''}
        onInputChange={onInputChange}
      />

      <div className="space-y-4">
        <h3 className="text-sm text-[#262626]">This employee is available for the following:</h3>
        <div className="border rounded-lg bg-[#FAFAFA] p-4">
          <CategorySelector 
            categories={serviceCategories}
            selectedCategories={employeeData.selectedCategories || []}
            onSelectCategory={onCategorySelect}
          />
        </div>

        <EmployeeOptions 
          useColorInCalendar={!!employeeData.useColorInCalendar}
          allowOnlineBooking={!!employeeData.allowOnlineBooking}
          manuallyManageTimetable={!!employeeData.manuallyManageTimetable}
          onCheckboxChange={onCheckboxChange}
        />
      </div>
    </div>
  );
};

export default EmployeeInfoStep;
