
import React from 'react';
import { ModalFooterProps } from './EmployeeModalTypes';

const EmployeeModalFooter: React.FC<ModalFooterProps> = ({
  step,
  setStep,
  onClose,
  onSave,
  validateStep1
}) => {
  return (
    <div className="px-6 py-4 border-t flex justify-between items-center bg-white">
      <div className="flex items-center space-x-2 text-sm">
        <button
          onClick={() => setStep(1)}
          className={`rounded-md px-4 py-2 ${
            step === 1 ? 'text-[#6366F1] bg-[#EEF2FF]' : 'text-gray-500 bg-gray-100'
          }`}
        >
          Employee information
        </button>
        <span className="text-gray-300">→</span>
        <button
          onClick={() => validateStep1() && setStep(2)}
          className={`rounded-md px-4 py-2 ${
            step === 2 ? 'text-[#6366F1] bg-[#EEF2FF]' : 'text-gray-500 bg-gray-100'
          }`}
        >
          Booking options
        </button>
      </div>
      
      <div className="flex space-x-3">
        <button
          onClick={onClose}
          className="px-6 py-2 text-[#6366F1] hover:bg-gray-50 rounded-md border border-[#6366F1]"
        >
          Cancel
        </button>
        <button
          onClick={step === 1 ? () => validateStep1() && setStep(2) : onSave}
          className="px-6 py-2 bg-[#6366F1] text-white rounded-md hover:bg-[#6366F1]/90"
        >
          {step === 1 ? 'Next' : 'Save'}
        </button>
      </div>
    </div>
  );
};

export default EmployeeModalFooter;
