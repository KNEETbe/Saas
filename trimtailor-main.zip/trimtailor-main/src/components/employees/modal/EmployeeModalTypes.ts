
import { Category } from '@/types/employee';

export interface EmployeeData {
  name: string;
  position?: string;
  email: string;
  phone: string;
  gender?: string;
  color?: string;
  image?: string;
  useColorInCalendar?: boolean;
  allowOnlineBooking?: boolean;
  manuallyManageTimetable?: boolean;
  categoryColor?: string;
  selectedCategories?: string[];
}

export interface EmployeeModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (employee: EmployeeData) => void;
}

export interface StepProps {
  employeeData: EmployeeData;
  onInputChange: (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => void;
  onCheckboxChange: (e: React.ChangeEvent<HTMLInputElement>) => void;
  onCategorySelect: (categoryId: string) => void;
  onColorSelect: (color: string) => void;
}

export interface ModalFooterProps {
  step: number;
  setStep: (step: number) => void;
  onClose: () => void;
  onSave: () => void;
  validateStep1: () => boolean;
}
