
import React from 'react';
import EmployeeCard from './EmployeeCard';
import { Employee } from '@/types/employee';

interface EmployeesListProps {
  employees: Employee[];
  activeDropdown: string | null;
  onDropdownToggle: (id: string) => void;
  onDeleteEmployee: (id: string) => void;
  onEditEmployee: (employee: Employee) => void;
}

const EmployeesList: React.FC<EmployeesListProps> = ({ 
  employees, 
  activeDropdown, 
  onDropdownToggle,
  onDeleteEmployee,
  onEditEmployee
}) => {
  return (
    <div className="bg-white rounded-lg p-6 shadow-sm border border-gray-100">
      <h2 className="text-lg font-medium mb-2">Employees List</h2>
      <p className="text-sm text-gray-500 mb-6">
        Manage your employees efficiently by adding, updating, or removing entries as needed.
      </p>

      {/* Employees List */}
      <div className="space-y-4">
        {employees.map((employee) => (
          <EmployeeCard
            key={employee.id}
            employee={employee}
            activeDropdown={activeDropdown}
            onDropdownToggle={onDropdownToggle}
            onDeleteEmployee={onDeleteEmployee}
            onEditEmployee={onEditEmployee}
          />
        ))}
      </div>
    </div>
  );
};

export default EmployeesList;
