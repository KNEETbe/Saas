
import React, { useState, useEffect } from 'react';
import { X } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import BookingOptions from './form/BookingOptions';
import EmployeeInfoStep from './modal/EmployeeInfoStep';
import EmployeeModalFooter from './modal/EmployeeModalFooter';
import { EmployeeData, EmployeeModalProps } from './modal/EmployeeModalTypes';
import { Employee } from '@/types/employee';
import { serviceCategories } from '@/data/employee-categories';

interface ExtendedEmployeeModalProps extends EmployeeModalProps {
  employee?: Employee;
  isEditing?: boolean;
}

const AddEmployeeModal: React.FC<ExtendedEmployeeModalProps> = ({ 
  isOpen, 
  onClose, 
  onSave, 
  employee, 
  isEditing = false 
}) => {
  const [employeeData, setEmployeeData] = useState<EmployeeData>({
    name: '',
    position: '',
    email: 'dwight.schrute@test.com',
    phone: '+32 (0) 000 00 00 00',
    gender: 'M',
    color: '#6366F1',
    useColorInCalendar: false,
    allowOnlineBooking: true,
    manuallyManageTimetable: true,
    selectedCategories: [],
  });
  
  // When in edit mode, populate the form with the existing employee data
  useEffect(() => {
    if (isEditing && employee) {
      // Extract category IDs for the selected categories
      const selectedCategories = employee.categories?.map(cat => {
        // Try to find the original category by matching properties
        const originalCategory = serviceCategories.find(sc => 
          sc.name === cat.name && 
          sc.color === cat.color &&
          sc.borderColor === cat.borderColor &&
          sc.backgroundColor === cat.backgroundColor
        );
        return originalCategory?.id || '';
      }).filter(id => id !== '') || [];

      setEmployeeData({
        name: employee.name || '',
        position: employee.position || '',
        email: employee.email || '',
        phone: employee.phone || '',
        gender: employee.gender || 'M',
        color: employee.color || '#6366F1',
        useColorInCalendar: employee.useColorInCalendar || false,
        allowOnlineBooking: employee.allowOnlineBooking || true,
        manuallyManageTimetable: employee.manuallyManageTimetable || true,
        selectedCategories,
        categoryColor: employee.categoryColor
      });
    }
  }, [isEditing, employee]);
  
  const [step, setStep] = useState(1);
  const { toast } = useToast();

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setEmployeeData(prev => ({ ...prev, [name]: value }));
  };

  const handleCheckboxChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, checked } = e.target;
    setEmployeeData(prev => ({ ...prev, [name]: checked }));
  };

  const handleCategorySelect = (categoryId: string) => {
    setEmployeeData(prev => {
      const selectedCategories = prev.selectedCategories || [];
      if (selectedCategories.includes(categoryId)) {
        return {
          ...prev,
          selectedCategories: selectedCategories.filter(id => id !== categoryId)
        };
      } else {
        return {
          ...prev,
          selectedCategories: [...selectedCategories, categoryId]
        };
      }
    });
  };

  const handleColorSelect = (color: string) => {
    setEmployeeData(prev => ({
      ...prev,
      categoryColor: color
    }));
  };

  const validateStep1 = () => {
    if (!employeeData.name || !employeeData.email || !employeeData.gender) {
      toast({
        title: "Required fields missing",
        description: "Please fill in all required fields",
        variant: "destructive"
      });
      return false;
    }
    return true;
  };

  const handleSave = () => {
    onSave(employeeData);
    onClose();
    
    toast({
      title: isEditing ? "Employee updated" : "Employee added",
      description: isEditing 
        ? "The employee has been successfully updated" 
        : "The employee has been successfully added",
    });
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 flex items-center justify-center z-50 bg-black/20">
      <div className="bg-white w-[600px] rounded-lg shadow-lg max-h-[90vh] flex flex-col">
        <div className="px-6 py-4 flex justify-between items-center border-b">
          <h2 className="text-xl font-medium text-[#262626]">
            {isEditing ? 'Edit employee' : 'Add employee'}
          </h2>
          <button 
            onClick={onClose}
            className="text-gray-400 hover:text-gray-500"
          >
            <X size={20} />
          </button>
        </div>
        
        <div className="p-6 overflow-y-auto flex-1">
          {step === 1 ? (
            <EmployeeInfoStep 
              employeeData={employeeData}
              onInputChange={handleInputChange}
              onCheckboxChange={handleCheckboxChange}
              onCategorySelect={handleCategorySelect}
              onColorSelect={handleColorSelect}
            />
          ) : (
            <BookingOptions />
          )}
        </div>
        
        <EmployeeModalFooter 
          step={step}
          setStep={setStep}
          onClose={onClose}
          onSave={handleSave}
          validateStep1={validateStep1}
        />
      </div>
    </div>
  );
};

export default AddEmployeeModal;
