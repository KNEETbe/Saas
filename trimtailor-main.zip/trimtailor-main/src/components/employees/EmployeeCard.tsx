
import React from 'react';
import { MoreVertical, Eye, Edit, Trash, Check } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Employee, Category } from '@/types/employee';
import { serviceCategories } from '@/data/employee-categories';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

interface EmployeeCardProps {
  employee: Employee;
  activeDropdown: string | null;
  onDropdownToggle: (id: string) => void;
  onDeleteEmployee: (id: string) => void;
  onEditEmployee: (employee: Employee) => void;
}

export const categoryColors: Record<string, string> = {
  "#0EA5E9": "bg-[#0EA5E9] text-white",
  "#22C55E": "bg-[#22C55E] text-white",
  "#F97316": "bg-[#F97316] text-white",
  "#A855F7": "bg-[#A855F7] text-white",
  "#F43F5E": "bg-[#F43F5E] text-white",
};

const EmployeeCard: React.FC<EmployeeCardProps> = ({ 
  employee, 
  activeDropdown, 
  onDropdownToggle,
  onDeleteEmployee,
  onEditEmployee
}) => {
  const getCategoryClass = (color: string) => {
    return categoryColors[color] || "bg-gray-500 text-white";
  };

  const getServiceCategoryStyle = (category: Category) => {
    if (category.borderColor) {
      return {
        backgroundColor: "white",
        color: category.color || "#333",
        border: `2px solid ${category.borderColor}`,
      };
    }
    
    return {
      backgroundColor: category.backgroundColor || category.color || "#0EA5E9",
      color: "white",
      border: "none",
    };
  };

  const renderCategoryIcon = (iconName?: string) => {
    if (iconName === 'check') {
      return <Check size={12} />;
    }
    return null;
  };

  const handleViewDetails = () => {
    onEditEmployee(employee);
  };

  return (
    <div className="flex items-center justify-between py-4 px-4 border border-gray-100 rounded-lg shadow-sm hover:shadow-md transition-all cursor-pointer"
         onClick={handleViewDetails}>
      <div className="flex items-center">
        {employee.initials ? (
          <div 
            className="w-10 h-10 rounded-full flex items-center justify-center text-white mr-4"
            style={{ backgroundColor: employee.color || '#6366F1' }}
          >
            {employee.initials}
          </div>
        ) : (
          <div className="w-10 h-10 rounded-full bg-gray-200 mr-4 flex items-center justify-center">
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <path d="M20 21V19C20 17.9391 19.5786 16.9217 18.8284 16.1716C18.0783 15.4214 17.0609 15 16 15H8C6.93913 15 5.92172 15.4214 5.17157 16.1716C4.42143 16.9217 4 17.9391 4 19V21" stroke="#666" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
              <path d="M12 11C14.2091 11 16 9.20914 16 7C16 4.79086 14.2091 3 12 3C9.79086 3 8 4.79086 8 7C8 9.20914 9.79086 11 12 11Z" stroke="#666" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
            </svg>
          </div>
        )}
        <span className="font-medium">{employee.name}</span>
      </div>

      <div className="flex items-center gap-3">
        <div className="flex gap-2">
          {employee.categories?.map((category, idx) => (
            <span 
              key={idx}
              className="text-xs px-3 py-1 rounded-full flex items-center gap-1"
              style={getServiceCategoryStyle(category)}
            >
              {renderCategoryIcon(category.iconName)}
              {category.name}
            </span>
          ))}
          
          {employee.additionalCategories && (
            <span className="text-xs px-3 py-1 rounded-full bg-gray-200 text-gray-600">
              +{employee.additionalCategories}
            </span>
          )}
        </div>
        
        <DropdownMenu open={activeDropdown === employee.id} onOpenChange={() => onDropdownToggle(employee.id)}>
          <DropdownMenuTrigger asChild>
            <Button 
              variant="ghost" 
              size="icon" 
              className="h-8 w-8 ml-2" 
              onClick={(e) => {
                e.stopPropagation(); // Prevent triggering the card click
              }}
            >
              <MoreVertical size={16} />
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end" className="w-[160px]">
            <DropdownMenuItem 
              className="cursor-pointer flex items-center gap-2"
              onClick={(e) => {
                e.stopPropagation();
                onEditEmployee(employee);
              }}
            >
              <Eye size={16} className="text-gray-600" />
              <span>View details</span>
            </DropdownMenuItem>
            <DropdownMenuItem 
              className="cursor-pointer flex items-center gap-2"
              onClick={(e) => {
                e.stopPropagation();
                onEditEmployee(employee);
              }}
            >
              <Edit size={16} className="text-gray-600" />
              <span>Edit employee</span>
            </DropdownMenuItem>
            <DropdownMenuItem 
              className="cursor-pointer flex items-center gap-2 text-red-500" 
              onClick={(e) => {
                e.stopPropagation();
                onDeleteEmployee(employee.id);
              }}
            >
              <Trash size={16} className="text-red-500" />
              <span>Delete employee</span>
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      </div>
    </div>
  );
};

export default EmployeeCard;
