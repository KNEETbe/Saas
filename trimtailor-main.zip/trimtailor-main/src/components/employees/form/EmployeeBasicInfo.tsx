
import React from 'react';
import FormInput from './FormInput';
import GenderSelect from './GenderSelect';
import ColorPicker from './ColorPicker';

interface EmployeeBasicInfoProps {
  name: string;
  email: string;
  gender: string;
  phone: string;
  color: string;
  onInputChange: (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => void;
}

const EmployeeBasicInfo: React.FC<EmployeeBasicInfoProps> = ({
  name,
  email,
  gender,
  phone,
  color,
  onInputChange,
}) => {
  const handleColorSelect = (selectedColor: string) => {
    const event = {
      target: {
        name: 'color',
        value: selectedColor
      }
    } as React.ChangeEvent<HTMLInputElement>;
    onInputChange(event);
  };

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <FormInput
          label="NAME"
          name="name"
          value={name}
          onChange={onInputChange}
          placeholder="Name"
          required
        />
        
        <FormInput
          label="MAIL"
          name="email"
          value={email}
          onChange={onInputChange}
          placeholder="Email address"
          type="email"
          required
        />

        <GenderSelect value={gender} onChange={onInputChange} />
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <FormInput
          label="Phone Number"
          name="phone"
          value={phone}
          onChange={onInputChange}
          placeholder="+32 (0) 000 00 00 00"
          type="tel"
        />
        
        <div className="space-y-2">
          <label className="block text-xs font-medium text-gray-700 uppercase">
            PICK COLOR <span className="text-red-400">*</span>
          </label>
          <ColorPicker color={color} onColorSelect={handleColorSelect} />
        </div>

        <div className="space-y-2">
          <label className="block text-xs font-medium text-gray-700 uppercase">
            IMAGE
          </label>
          <div className="flex gap-2 items-center bg-[#FAFAFA] rounded-md p-2">
            <button className="text-gray-600 hover:text-gray-700">
              Upload image
            </button>
            {/* Add image preview here if needed */}
          </div>
        </div>
      </div>
    </div>
  );
};

export default EmployeeBasicInfo;
