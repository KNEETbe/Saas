
import React, { useState } from 'react';
import { Check } from 'lucide-react';
import CategorySelector, { CategoryOption } from './CategorySelector';
import { 
  Popover,
  PopoverContent,
  PopoverTrigger
} from '@/components/ui/popover';
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger
} from '@/components/ui/tooltip';

interface EmployeeServicesSectionProps {
  selectedColor: string;
  onColorChange: (color: string) => void;
  selectedCategories?: string[];
  onCategoriesChange?: (categories: string[]) => void;
}

const EmployeeServicesSection: React.FC<EmployeeServicesSectionProps> = ({ 
  selectedColor,
  onColorChange,
  selectedCategories = [],
  onCategoriesChange = () => {}
}) => {
  // Basic colors previously used
  const basicColors = [
    "#0EA5E9", // Blauw
    "#22C55E", // Groen
    "#F97316", // Oranje
    "#A855F7", // Paars
    "#F43F5E"  // Rood
  ];
  
  // Extended color palette from the image
  const colorPalette = {
    vibrant: [
      "#f44336", // Red
      "#ff9800", // Orange 
      "#ffeb3b", // Yellow
      "#4caf50", // Green
      "#26c6da", // Teal
      "#2196f3", // Blue
      "#673ab7", // Purple
    ],
    pastel: [
      "#ffcdd2", // Pink
      "#ffe0b2", // Light Orange 
      "#fff9c4", // Light Yellow
      "#c8e6c9", // Light Green
      "#b2ebf2", // Light Blue
      "#bbdefb", // Light Blue
      "#d1c4e9", // Light Purple
    ],
    dark: [
      "#b71c1c", // Dark Red
      "#004d40", // Dark Teal
      "#01579b", // Dark Blue
      "#1a237e", // Indigo
      "#4a148c", // Dark Purple
      "#9e9e9e", // Gray
      "#424242", // Dark Gray
    ]
  };
  
  const colorLabels: Record<string, string> = {
    "#0EA5E9": "Blauw",
    "#22C55E": "Groen",
    "#F97316": "Oranje",
    "#A855F7": "Paars",
    "#F43F5E": "Rood",
  };

  // Default categories based on colors
  const availableCategories: CategoryOption[] = [
    { id: "1", name: "Category Blauw", color: "#0EA5E9" },
    { id: "2", name: "Category Groen", color: "#22C55E" },
    { id: "3", name: "Category Paars", color: "#A855F7" },
    { id: "4", name: "Category Oranje", color: "#F97316" },
  ];

  const handleCategorySelect = (categoryId: string) => {
    if (selectedCategories.includes(categoryId)) {
      onCategoriesChange(selectedCategories.filter(id => id !== categoryId));
    } else {
      onCategoriesChange([...selectedCategories, categoryId]);
    }
  };

  return (
    <div className="space-y-4">
      <h3 className="text-base font-medium text-[#262626]">Category & services</h3>
      <div className="border border-[rgba(238,238,238,0.5)] rounded-lg p-4 bg-white">
        <div className="flex flex-wrap gap-3 mb-4">
          <Popover>
            <PopoverTrigger asChild>
              <button
                className="flex items-center space-x-2 p-3 rounded-md border border-gray-200 hover:bg-gray-50"
                type="button"
              >
                <div className="w-5 h-5 rounded-full" style={{ backgroundColor: selectedColor }} />
                <span className="text-sm">Pick color</span>
              </button>
            </PopoverTrigger>
            <PopoverContent className="w-64 p-3">
              <div className="space-y-3">
                <p className="text-sm font-medium text-gray-700">Colors:</p>
                
                <div className="space-y-2">
                  <div className="flex flex-wrap gap-2">
                    {colorPalette.vibrant.map((color) => (
                      <TooltipProvider key={color}>
                        <Tooltip>
                          <TooltipTrigger asChild>
                            <button
                              onClick={() => onColorChange(color)}
                              className={`w-8 h-8 rounded-full transition-transform ${selectedColor === color ? 'ring-2 ring-offset-2 ring-gray-400 scale-110' : 'hover:scale-110'}`}
                              style={{ backgroundColor: color }}
                              aria-label={`Select ${color} color`}
                            />
                          </TooltipTrigger>
                          <TooltipContent>
                            <p>{color}</p>
                          </TooltipContent>
                        </Tooltip>
                      </TooltipProvider>
                    ))}
                  </div>
                  
                  <div className="flex flex-wrap gap-2">
                    {colorPalette.pastel.map((color) => (
                      <TooltipProvider key={color}>
                        <Tooltip>
                          <TooltipTrigger asChild>
                            <button
                              onClick={() => onColorChange(color)}
                              className={`w-8 h-8 rounded-full transition-transform ${selectedColor === color ? 'ring-2 ring-offset-2 ring-gray-400 scale-110' : 'hover:scale-110'}`}
                              style={{ backgroundColor: color }}
                              aria-label={`Select ${color} color`}
                            />
                          </TooltipTrigger>
                          <TooltipContent>
                            <p>{color}</p>
                          </TooltipContent>
                        </Tooltip>
                      </TooltipProvider>
                    ))}
                  </div>
                  
                  <div className="flex flex-wrap gap-2">
                    {colorPalette.dark.map((color) => (
                      <TooltipProvider key={color}>
                        <Tooltip>
                          <TooltipTrigger asChild>
                            <button
                              onClick={() => onColorChange(color)}
                              className={`w-8 h-8 rounded-full transition-transform ${selectedColor === color ? 'ring-2 ring-offset-2 ring-gray-400 scale-110' : 'hover:scale-110'}`}
                              style={{ backgroundColor: color }}
                              aria-label={`Select ${color} color`}
                            />
                          </TooltipTrigger>
                          <TooltipContent>
                            <p>{color}</p>
                          </TooltipContent>
                        </Tooltip>
                      </TooltipProvider>
                    ))}
                  </div>
                </div>
              </div>
            </PopoverContent>
          </Popover>
          
          {basicColors.map((color) => (
            <button
              key={color}
              onClick={() => onColorChange(color)}
              className={`flex items-center space-x-2 p-3 rounded-md border ${
                selectedColor === color 
                  ? 'border-gray-400 bg-gray-50' 
                  : 'border-gray-200 hover:bg-gray-50'
              }`}
              type="button"
            >
              <div 
                className="w-5 h-5 rounded-full" 
                style={{ backgroundColor: color }}
              />
              <span className="text-sm">{colorLabels[color]}</span>
            </button>
          ))}
        </div>

        <div className="border-t border-gray-100 pt-4">
          <p className="text-sm text-[#7A7A7A] mb-4">
            This employee is available for the following:
          </p>
          
          <CategorySelector 
            categories={availableCategories}
            selectedCategories={selectedCategories}
            onSelectCategory={handleCategorySelect}
          />
        </div>
      </div>
    </div>
  );
};

export default EmployeeServicesSection;
