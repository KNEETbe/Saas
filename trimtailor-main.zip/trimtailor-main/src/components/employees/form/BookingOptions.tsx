
import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Clock, Plus, Trash2 } from 'lucide-react';

interface TimeSlot {
  id: string;
  day: string;
  startTime: string;
  endTime: string;
}

interface BookingOptionsProps {
  availableTimeSlots?: TimeSlot[];
  onTimeSlotsChange?: (timeSlots: TimeSlot[]) => void;
}

const days = [
  "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"
];

const BookingOptions: React.FC<BookingOptionsProps> = ({ 
  availableTimeSlots = [], 
  onTimeSlotsChange = () => {} 
}) => {
  const [timeSlots, setTimeSlots] = useState<TimeSlot[]>(availableTimeSlots);
  
  const addTimeSlot = () => {
    const newTimeSlot: TimeSlot = {
      id: Date.now().toString(),
      day: days[0],
      startTime: '09:00',
      endTime: '17:00'
    };
    
    const updatedTimeSlots = [...timeSlots, newTimeSlot];
    setTimeSlots(updatedTimeSlots);
    onTimeSlotsChange(updatedTimeSlots);
  };
  
  const removeTimeSlot = (id: string) => {
    const updatedTimeSlots = timeSlots.filter(slot => slot.id !== id);
    setTimeSlots(updatedTimeSlots);
    onTimeSlotsChange(updatedTimeSlots);
  };
  
  const updateTimeSlot = (id: string, field: keyof TimeSlot, value: string) => {
    const updatedTimeSlots = timeSlots.map(slot => {
      if (slot.id === id) {
        return { ...slot, [field]: value };
      }
      return slot;
    });
    
    setTimeSlots(updatedTimeSlots);
    onTimeSlotsChange(updatedTimeSlots);
  };

  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center">
        <h3 className="text-lg font-medium">Booking Options</h3>
        <Button 
          variant="outline" 
          size="sm"
          className="border-[#6366F1] text-[#6366F1]"
          onClick={addTimeSlot}
        >
          <Plus size={16} className="mr-2" />
          Add Time Slot
        </Button>
      </div>
      <p className="text-sm text-gray-500">Configure booking options and working hours for this employee</p>
      
      {timeSlots.length === 0 ? (
        <div className="bg-gray-50 rounded-md p-6 text-center">
          <Clock className="mx-auto h-10 w-10 text-gray-400 mb-2" />
          <p className="text-gray-600">No time slots configured</p>
          <p className="text-sm text-gray-500 mb-4">Add working hours for this employee</p>
          <Button 
            variant="outline" 
            size="sm"
            className="border-[#6366F1] text-[#6366F1]"
            onClick={addTimeSlot}
          >
            <Plus size={16} className="mr-2" />
            Add Time Slot
          </Button>
        </div>
      ) : (
        <div className="space-y-3">
          {timeSlots.map((slot) => (
            <div key={slot.id} className="bg-gray-50 rounded-md p-4 flex items-center gap-3">
              <div className="flex-1">
                <select
                  value={slot.day}
                  onChange={(e) => updateTimeSlot(slot.id, 'day', e.target.value)}
                  className="bg-white border border-gray-300 px-2 py-1 rounded-md text-sm"
                >
                  {days.map((day) => (
                    <option key={day} value={day}>{day}</option>
                  ))}
                </select>
              </div>
              
              <div className="flex items-center gap-2">
                <input
                  type="time"
                  value={slot.startTime}
                  onChange={(e) => updateTimeSlot(slot.id, 'startTime', e.target.value)}
                  className="bg-white border border-gray-300 px-2 py-1 rounded-md text-sm"
                />
                <span className="text-gray-500">-</span>
                <input
                  type="time"
                  value={slot.endTime}
                  onChange={(e) => updateTimeSlot(slot.id, 'endTime', e.target.value)}
                  className="bg-white border border-gray-300 px-2 py-1 rounded-md text-sm"
                />
              </div>
              
              <Button
                variant="ghost"
                size="sm"
                onClick={() => removeTimeSlot(slot.id)}
                className="text-red-500 hover:text-red-700 hover:bg-red-50"
              >
                <Trash2 size={16} />
              </Button>
            </div>
          ))}
        </div>
      )}
      
      <div className="mt-6">
        <h4 className="text-md font-medium mb-2">Online Booking Settings</h4>
        <div className="space-y-2">
          <div className="flex items-center gap-2">
            <input 
              type="checkbox" 
              id="allowOnlineBooking" 
              className="rounded border-gray-300 text-[#6366F1] focus:ring-[#6366F1]" 
            />
            <label htmlFor="allowOnlineBooking" className="text-sm text-gray-700">
              Allow clients to book this employee online
            </label>
          </div>
          
          <div className="flex items-center gap-2">
            <input 
              type="checkbox" 
              id="requireApproval" 
              className="rounded border-gray-300 text-[#6366F1] focus:ring-[#6366F1]" 
            />
            <label htmlFor="requireApproval" className="text-sm text-gray-700">
              Require manual approval for online bookings
            </label>
          </div>
          
          <div className="flex items-center gap-2">
            <input 
              type="checkbox" 
              id="allowCancellations" 
              className="rounded border-gray-300 text-[#6366F1] focus:ring-[#6366F1]" 
            />
            <label htmlFor="allowCancellations" className="text-sm text-gray-700">
              Allow clients to cancel bookings online
            </label>
          </div>
        </div>
      </div>
    </div>
  );
};

export default BookingOptions;
