
import React from 'react';

interface GenderSelectProps {
  value: string;
  onChange: (e: React.ChangeEvent<HTMLSelectElement>) => void;
  label?: string;
  borderColor?: string;
  backgroundColor?: string;
}

const GenderSelect: React.FC<GenderSelectProps> = ({ 
  value, 
  onChange, 
  label = "GENDER",
  borderColor,
  backgroundColor,
}) => {
  return (
    <div className="space-y-2">
      <label className="block text-xs font-medium text-gray-700 uppercase flex items-center">
        {label} <span className="text-red-400 ml-1">*</span>
      </label>
      <div className="relative">
        <select
          name="gender"
          value={value}
          onChange={onChange}
          className={`w-full rounded h-10 px-3 text-sm text-[#262626] appearance-none focus:outline-none ${
            borderColor 
              ? 'border-2 bg-white' 
              : 'border-none bg-[#F5F5F5]'
          }`}
          style={{
            borderColor: borderColor || 'transparent',
            backgroundColor: backgroundColor || (borderColor ? 'white' : '#F5F5F5'),
          }}
        >
          <option value="M">M</option>
          <option value="F">F</option>
          <option value="Other">Other</option>
        </select>
        <div className="absolute right-3 top-1/2 -translate-y-1/2 pointer-events-none">
          <svg width="10" height="6" viewBox="0 0 10 6" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M1 1L5 5L9 1" stroke="#645F71" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
          </svg>
        </div>
      </div>
    </div>
  );
};

export default GenderSelect;
