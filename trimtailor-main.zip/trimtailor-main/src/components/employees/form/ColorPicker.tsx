
import React from 'react';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { Button } from '@/components/ui/button';

interface ColorPickerProps {
  color: string;
  onColorSelect: (color: string) => void;
}

const ColorPicker: React.FC<ColorPickerProps> = ({ color, onColorSelect }) => {
  // Color palette options - expanded with more vibrant options
  const colorOptions = [
    // Row 1 - Vibrant colors
    '#EF4444', '#F97316', '#F59E0B', '#EAB308', '#84CC16', 
    '#10B981', '#06B6D4', '#0EA5E9', '#3B82F6', '#6366F1',
    // Row 2 - Pastel colors  
    '#FCA5A5', '#FDBA74', '#FCD34D', '#BEF264', '#86EFAC',
    '#5EEAD4', '#7DD3FC', '#93C5FD', '#A5B4FC', '#C4B5FD',
    // Row 3 - Darker colors
    '#991B1B', '#9A3412', '#92400E', '#3F6212', '#065F46',
    '#155E75', '#0C4A6E', '#1E40AF', '#4338CA', '#6D28D9'
  ];

  return (
    <Popover>
      <PopoverTrigger asChild>
        <Button 
          variant="outline" 
          className="w-full h-10 flex justify-between items-center gap-2"
        >
          <div 
            className="w-5 h-5 rounded border border-gray-200"
            style={{ backgroundColor: color || '#6366F1' }}
          />
          <span className="flex-1 text-left">{color || 'Select color'}</span>
        </Button>
      </PopoverTrigger>
      <PopoverContent className="w-[300px] p-3">
        <div className="grid grid-cols-5 gap-2">
          {colorOptions.map((colorOption) => (
            <button
              key={colorOption}
              type="button"
              className="w-10 h-10 rounded border border-gray-200 cursor-pointer transition-transform hover:scale-110"
              style={{ backgroundColor: colorOption }}
              onClick={() => onColorSelect(colorOption)}
            />
          ))}
        </div>
      </PopoverContent>
    </Popover>
  );
};

export default ColorPicker;
