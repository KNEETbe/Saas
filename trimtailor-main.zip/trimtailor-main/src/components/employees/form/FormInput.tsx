
import React from 'react';

interface FormInputProps {
  label: string;
  name: string;
  value: string;
  onChange: (e: React.ChangeEvent<HTMLInputElement>) => void;
  type?: string;
  placeholder?: string;
  required?: boolean;
  borderColor?: string;
  backgroundColor?: string;
  icon?: React.ReactNode;
}

const FormInput: React.FC<FormInputProps> = ({
  label,
  name,
  value,
  onChange,
  type = 'text',
  placeholder,
  required = false,
  borderColor,
  backgroundColor,
  icon,
}) => {
  return (
    <div className="space-y-2">
      {label && (
        <label className="block text-xs font-medium text-gray-700 uppercase flex items-center">
          {label} {required && <span className="text-red-400 ml-1">*</span>}
        </label>
      )}
      <div className="relative">
        <input
          type={type}
          name={name}
          value={value}
          onChange={onChange}
          className={`w-full rounded h-10 px-3 text-sm text-[#262626] focus:outline-none ${
            borderColor 
              ? 'border-2 bg-white' 
              : 'border-none bg-[#F5F5F5]'
          }`}
          placeholder={placeholder}
          style={{
            borderColor: borderColor || 'transparent',
            backgroundColor: backgroundColor || (borderColor ? 'white' : '#F5F5F5'),
          }}
        />
        {icon && (
          <div className="absolute top-1/2 transform -translate-y-1/2 left-3 text-gray-400">
            {icon}
          </div>
        )}
      </div>
    </div>
  );
};

export default FormInput;
