
import React from 'react';

interface EmployeeOptionsProps {
  useColorInCalendar: boolean;
  allowOnlineBooking: boolean;
  manuallyManageTimetable: boolean;
  onCheckboxChange: (e: React.ChangeEvent<HTMLInputElement>) => void;
}

const EmployeeOptions: React.FC<EmployeeOptionsProps> = ({
  useColorInCalendar,
  allowOnlineBooking,
  manuallyManageTimetable,
  onCheckboxChange,
}) => {
  return (
    <div className="space-y-4 py-2">
      <label className="flex items-center gap-3 cursor-pointer">
        <input
          type="checkbox"
          name="useColorInCalendar"
          checked={useColorInCalendar}
          onChange={onCheckboxChange}
          className="h-4 w-4 rounded border-gray-300 text-[#6366F1] focus:ring-[#6366F1]"
        />
        <span className="text-sm text-[#262626]">
          Use employee's color to show in appointments calendar
        </span>
      </label>
      
      <label className="flex items-center gap-3 cursor-pointer">
        <input
          type="checkbox"
          name="allowOnlineBooking"
          checked={allowOnlineBooking}
          onChange={onCheckboxChange}
          className="h-4 w-4 rounded border-gray-300 text-[#6366F1] focus:ring-[#6366F1]"
        />
        <span className="text-sm text-[#262626]">
          Allow this employee to be bookable online
        </span>
      </label>
      
      <label className="flex items-center gap-3 cursor-pointer">
        <input
          type="checkbox"
          name="manuallyManageTimetable"
          checked={manuallyManageTimetable}
          onChange={onCheckboxChange}
          className="h-4 w-4 rounded border-gray-300 text-[#6366F1] focus:ring-[#6366F1]"
        />
        <span className="text-sm text-[#262626]">
          Manually manage this employee timetable
        </span>
      </label>
    </div>
  );
};

export default EmployeeOptions;
