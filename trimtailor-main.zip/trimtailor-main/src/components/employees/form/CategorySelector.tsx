
import React from 'react';
import { Check } from 'lucide-react';
import { Category } from '@/types/employee';

export interface CategoryOption {
  id: string;
  name: string;
  color: string;
  borderColor?: string;
  backgroundColor?: string;
  iconName?: string;
}

interface CategorySelectorProps {
  categories: Category[] | CategoryOption[];
  selectedCategories: string[];
  onSelectCategory: (categoryId: string) => void;
}

const CategorySelector: React.FC<CategorySelectorProps> = ({
  categories,
  selectedCategories,
  onSelectCategory
}) => {
  const getCategoryStyle = (category: Category | CategoryOption) => {
    const baseStyle = "flex items-center gap-2 w-full text-sm";
    if (category.borderColor) {
      return `${baseStyle} px-3 py-1.5 rounded-full border-2 text-[#262626]`;
    }
    return `${baseStyle} px-3 py-1.5 rounded-full text-white`;
  };

  return (
    <div className="space-y-3">
      {categories.map((category) => (
        <div key={category.id} className="flex items-start gap-3">
          <div 
            className="flex-shrink-0 w-4 h-4 mt-2 rounded border cursor-pointer"
            style={{ borderColor: selectedCategories.includes(category.id || '') ? '#6366F1' : '#E5E7EB' }}
            onClick={() => onSelectCategory(category.id || '')}
          >
            {selectedCategories.includes(category.id || '') && (
              <Check size={14} className="text-[#6366F1]" />
            )}
          </div>
          <div className="flex-1">
            <div 
              className={getCategoryStyle(category)}
              style={{
                backgroundColor: category.backgroundColor,
                borderColor: category.borderColor,
                color: category.borderColor ? '#262626' : 'white'
              }}
            >
              <span className="flex-1">{category.name}</span>
              {category.iconName === 'check' && <Check size={14} />}
            </div>
            {category.id === "1" && (
              <div className="mt-2 ml-4 space-y-2">
                <div className="text-sm text-gray-600">Service variant | Service variant | Service variant</div>
                <div className="text-sm text-gray-600">Service variant | Service variant | Service variant</div>
              </div>
            )}
          </div>
        </div>
      ))}
    </div>
  );
};

export default CategorySelector;
