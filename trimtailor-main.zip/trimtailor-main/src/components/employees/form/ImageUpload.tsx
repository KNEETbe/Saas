
import React from 'react';
import { Upload } from 'lucide-react';

interface ImageUploadProps {
  image?: string;
  onInputChange: (e: React.ChangeEvent<HTMLInputElement>) => void;
}

const ImageUpload: React.FC<ImageUploadProps> = ({ image, onInputChange }) => {
  return (
    <div className="space-y-2">
      <label className="block text-xs font-medium text-gray-700 uppercase">
        Image
      </label>
      <div className="flex gap-2 items-center">
        <div className="flex-1 bg-[#F5F5F5] rounded h-10 flex items-center px-3 gap-2 cursor-pointer">
          <Upload size={16} />
          <span className="text-sm font-[Poppins] text-[#262626] opacity-70">Upload image</span>
        </div>
        <div className={`w-10 h-10 rounded-full bg-[#F5F5F5] ${image ? 'bg-cover bg-center' : ''}`} 
             style={image ? { backgroundImage: `url(${image})` } : {}}></div>
      </div>
    </div>
  );
};

export default ImageUpload;
