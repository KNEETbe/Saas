
import React from 'react';
import { Button } from '@/components/ui/button';

interface ModalFooterProps {
  step: number;
  onPrevious: () => void;
  onNext: () => void;
  onSave: () => void;
  onCancel: () => void;
}

const ModalFooter: React.FC<ModalFooterProps> = ({ 
  step, 
  onPrevious, 
  onNext, 
  onSave, 
  onCancel 
}) => {
  return (
    <>
      <div className="w-full h-[1px] bg-[rgba(3,2,41,0.05)] mt-6"></div>
      
      <div className="flex items-center justify-between mt-4">
        <div className="flex items-center gap-2 text-xs text-[#9A98A1] font-medium">
          <span className={step === 1 ? "text-[#6366F1] font-semibold" : ""}>Employee information</span>
          <svg width="15" height="16" viewBox="0 0 15 16" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M13.5 7.625L8.64844 2.70312C8.4375 2.49219 8.10938 2.49219 7.89844 2.70312C7.6875 2.91406 7.6875 3.24219 7.89844 3.45313L11.8359 7.46094H1.875C1.59375 7.46094 1.35938 7.69531 1.35938 7.97656C1.35938 8.25781 1.59375 8.51562 1.875 8.51562H11.8828L7.89844 12.5703C7.6875 12.7812 7.6875 13.1094 7.89844 13.3203C7.99219 13.4141 8.13281 13.4609 8.27344 13.4609C8.41406 13.4609 8.55469 13.4141 8.64844 13.2969L13.5 8.375C13.7109 8.16406 13.7109 7.83594 13.5 7.625Z" fill="#9A98A1"/>
          </svg>
          <span className={step === 2 ? "text-[#6366F1] font-semibold" : ""}>Booking options</span>
        </div>
        
        <div className="flex gap-3">
          {step === 2 ? (
            <>
              <Button 
                variant="outline" 
                className="border-[#6366F1] text-[#6366F1] hover:bg-[#6366F1]/10 font-medium"
                onClick={onPrevious}
              >
                Previous
              </Button>
              <Button 
                className="bg-[#6366F1] hover:bg-[#4F46E5] font-medium"
                onClick={onSave}
              >
                Save
              </Button>
            </>
          ) : (
            <>
              <Button 
                variant="outline" 
                className="border-[#6366F1] text-[#6366F1] hover:bg-[#6366F1]/10 font-medium"
                onClick={onCancel}
              >
                Cancel
              </Button>
              <Button 
                className="bg-[#6366F1] hover:bg-[#4F46E5] font-medium"
                onClick={onNext}
              >
                Next
              </Button>
            </>
          )}
        </div>
      </div>
    </>
  );
};

export default ModalFooter;
