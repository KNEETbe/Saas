
import React, { useState } from 'react';
import { ChevronDown } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

interface LogEntry {
  date: string;
  user: {
    initials: string;
    name: string;
    email: string;
  };
  type: string;
  status: 'Delivered' | 'Bounced';
}

const EmailLog: React.FC = () => {
  const [isOpen, setIsOpen] = useState(true);
  const { toast } = useToast();
  
  const logEntries: LogEntry[] = [
    {
      date: '08 Feb 2025, 5:30 PM',
      user: {
        initials: 'AC',
        name: 'Alex Carter',
        email: 'alex.carter@gmail.com'
      },
      type: 'Confirmation booking',
      status: 'Delivered'
    },
    {
      date: '06 Feb 2025, 11:00 PM',
      user: {
        initials: 'JB',
        name: 'Jamie Brooks',
        email: 'jamie.brooks@gmail.com'
      },
      type: 'Before appoinment',
      status: 'Bounced'
    }
  ];

  const handleEntryClick = (entry: LogEntry) => {
    toast({
      title: `Email ${entry.status}`,
      description: `Details for email sent to ${entry.user.name} on ${entry.date}`,
    });
  };

  return (
    <div className="flex flex-col gap-4 p-6 bg-white rounded-lg border border-[rgba(217,218,222,0.3)]">
      <div className="flex flex-col gap-2">
        <h2 className="font-['Poppins'] text-base font-bold text-[#030229]">Email Log</h2>
        <p className="font-['Poppins'] text-xs text-[#030229]">
          The system sends automated emails. Check here to see which emails have been sent by the platform.
        </p>
      </div>
      
      <div className="w-full h-[2px] bg-[#030229] opacity-5 my-2" />
      
      <div className="flex justify-between items-center cursor-pointer font-['Poppins'] text-[15.7px] font-semibold text-[#030229]" 
           onClick={() => setIsOpen(!isOpen)}>
        <span>Email Log</span>
        <ChevronDown className={`w-4 h-4 text-[#645F71] transition-transform ${isOpen ? '' : 'transform rotate-180'}`} />
      </div>
      
      {isOpen && (
        <div className="px-3">
          <div className="flex items-center gap-[71px] py-2 font-['Poppins'] text-xs text-black md:gap-10 md:flex-wrap sm:gap-5">
            <div className="flex items-center gap-2 cursor-pointer hover:text-[#4A4CA0]">
              Date & Time
              <ChevronDown className="w-3 h-3" />
            </div>
            <div className="cursor-pointer hover:text-[#4A4CA0]">Send to</div>
            <div className="cursor-pointer hover:text-[#4A4CA0]">Type</div>
            <div className="cursor-pointer hover:text-[#4A4CA0]">Status</div>
          </div>
          
          <div className="flex flex-col gap-1">
            {logEntries.map((entry, index) => (
              <div 
                key={index} 
                className="flex items-center p-2 px-6 bg-[#FAFAFB] md:flex-wrap md:gap-2 sm:flex-col sm:items-start sm:gap-2 cursor-pointer hover:bg-[#F0F0F5]"
                onClick={() => handleEntryClick(entry)}
              >
                <div className="w-[152px] font-['Poppins'] text-xs text-black sm:w-full">
                  {entry.date}
                </div>
                <div className="flex items-center gap-1.5 sm:w-full">
                  <div className="flex justify-center items-center w-[25px] h-[25px] bg-[#D9DADE] rounded-[12.5px] font-['Poppins'] text-[10.714px] text-black">
                    {entry.user.initials}
                  </div>
                  <div className="font-['Poppins'] text-xs text-[#312E81]">
                    {entry.user.name}
                  </div>
                  <div className="font-['Poppins'] text-xs text-black">
                    - {entry.user.email}
                  </div>
                </div>
                <div className="font-['Poppins'] text-xs text-black sm:w-full">
                  {entry.type}
                </div>
                <div className={`px-4 py-1 rounded-[60px] font-['Poppins'] text-xs text-white
                  ${entry.status === 'Delivered' ? 'bg-[#22C55E] border-[#22C55E]' : 'bg-[#F43F5E] border-[#EF4444]'}`}>
                  {entry.status}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};

export default EmailLog;
