
import React, { useState } from 'react';
import Toggle from './Toggle';
import { ChevronDown } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import EmailEditorModal from './EmailEditorModal';

interface EmailSetting {
  label: string;
  description: string;
  active: boolean;
}

interface EmailSectionProps {
  title: string;
  description: string;
  settings: EmailSetting[];
}

const EmailSection: React.FC<EmailSectionProps> = ({ title, description, settings: initialSettings }) => {
  const [isOpen, setIsOpen] = useState(true);
  const [settings, setSettings] = useState<EmailSetting[]>(initialSettings);
  const { toast } = useToast();
  const [showEmailEditor, setShowEmailEditor] = useState(false);
  const [currentEditingEmail, setCurrentEditingEmail] = useState('');

  const toggleSetting = (index: number) => {
    const updatedSettings = [...settings];
    updatedSettings[index] = {
      ...updatedSettings[index],
      active: !updatedSettings[index].active
    };
    setSettings(updatedSettings);
    
    toast({
      title: updatedSettings[index].active ? "Enabled" : "Disabled",
      description: `Email notification for "${updatedSettings[index].label}" has been ${updatedSettings[index].active ? "enabled" : "disabled"}.`,
    });
  };

  const handleEditContent = (index: number) => {
    setCurrentEditingEmail(settings[index].label);
    setShowEmailEditor(true);
  };

  return (
    <>
      <div className="flex flex-col gap-4 p-6 bg-white rounded-lg border border-[rgba(217,218,222,0.3)]">
        <div className="flex flex-col gap-2">
          <h2 className="font-['Poppins'] text-base font-bold text-[#030229]">{title}</h2>
          <p className="font-['Poppins'] text-xs text-[#030229]">{description}</p>
        </div>
        
        <div className="w-full h-[2px] bg-[#030229] opacity-5 my-2" />
        
        <div className="flex flex-col gap-4">
          <div 
            className="flex justify-between items-center cursor-pointer font-['Poppins'] text-[15.7px] font-semibold text-[#030229]"
            onClick={() => setIsOpen(!isOpen)}
          >
            <span>{title}</span>
            <ChevronDown className={`w-4 h-4 text-[#645F71] transition-transform ${isOpen ? '' : 'transform rotate-180'}`} />
          </div>
          
          {isOpen && (
            <div className="flex flex-col gap-1">
              {settings.map((setting, index) => (
                <div key={index} className="flex justify-between items-center p-2 px-6 py-2 bg-[#FAFAFB]">
                  <div className="flex items-center gap-3">
                    <Toggle 
                      active={setting.active} 
                      onClick={() => toggleSetting(index)} 
                    />
                    <span className="font-['Poppins'] text-xs text-black">{setting.label}</span>
                    <span className="font-['Poppins'] text-xs text-black">-</span>
                    <span className="font-['Poppins'] text-xs text-black">{setting.description}</span>
                  </div>
                  <button 
                    className="bg-[rgba(74,76,160,0.1)] px-2 py-1.5 rounded text-sm font-['Outfit'] text-[#262626] hover:bg-[rgba(74,76,160,0.2)] transition-colors"
                    onClick={(e) => {
                      e.stopPropagation();
                      handleEditContent(index);
                    }}
                  >
                    Edit content
                  </button>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      {showEmailEditor && (
        <EmailEditorModal 
          isOpen={showEmailEditor}
          onClose={() => setShowEmailEditor(false)}
          emailType={currentEditingEmail}
        />
      )}
    </>
  );
};

export default EmailSection;
