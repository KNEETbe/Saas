
import React from 'react';

interface ToggleProps {
  active: boolean;
  onClick: () => void;
}

const Toggle: React.FC<ToggleProps> = ({ active, onClick }) => {
  return (
    <div 
      onClick={onClick}
      className={`w-[25.2px] h-[14.4px] rounded-[27.9px] cursor-pointer relative
        ${active ? 'bg-[#4A4CA0]' : 'bg-[#D9DADE]'}`}
    >
      <div 
        className={`absolute w-3 h-3 bg-white rounded-full top-[1px] transition-all
          ${active ? 'right-[1px]' : 'left-[1px]'}`}
      />
    </div>
  );
};

export default Toggle;
