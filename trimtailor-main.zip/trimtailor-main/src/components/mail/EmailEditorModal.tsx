import React, { useState } from 'react';
import { useToast } from '@/hooks/use-toast';
import { Button } from '@/components/ui/button';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { ChevronDown, X, Undo, Redo, AlignLeft, AlignCenter, AlignRight, Bold, Italic, Underline, Strikethrough, ListOrdered, List, AlertCircle, ExternalLink } from 'lucide-react';

interface EmailEditorModalProps {
  isOpen: boolean;
  onClose: () => void;
  emailType: string;
}

const EmailEditorModal: React.FC<EmailEditorModalProps> = ({ isOpen, onClose, emailType }) => {
  const { toast } = useToast();
  const [emailSubject, setEmailSubject] = useState("Appointment Confirmation – %appointment_date%");
  const [emailContent, setEmailContent] = useState(`Dear %customer_name%,

Your appointment has been successfully approved! Here are the details:
📅 Date: %appointment_date%
⏰ Time: %appointment_time%
📍 Location: %appointment_location%

If you have any questions or need to reschedule, please contact us at %company_email% or visit %company_website%.

We look forward to seeing you!

Best regards,
%company_name%`);

  const handleSave = () => {
    toast({
      title: "Email template saved",
      description: `The ${emailType} email template has been updated successfully.`,
    });
    onClose();
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4 overflow-auto">
      <div className="bg-white rounded-lg border border-[rgba(217,218,222,0.3)] max-w-[1189px] w-full max-h-[90vh] overflow-auto">
        <div className="flex flex-col p-6 gap-4">
          {/* Header */}
          <div className="flex justify-between items-center w-full pb-2.5 border-b-2 border-[rgba(3,2,41,0.05)]">
            <h2 className="font-['Poppins'] text-[20.7px] font-semibold text-[#262626]">Edit mail</h2>
            <X 
              className="w-4 h-4 text-[#9A98A1] cursor-pointer" 
              onClick={onClose}
            />
          </div>

          {/* Content */}
          <div className="flex gap-4 flex-col md:flex-row">
            {/* Left column - Editor */}
            <div className="flex-1">
              {/* Email subject */}
              <div className="mb-4">
                <div className="flex items-center gap-1">
                  <span className="font-['Poppins'] text-xs text-[#262626] uppercase">Email subject</span>
                  <span className="text-[#F87171]">*</span>
                </div>
                <div className="mt-2 p-4 border border-[#D9DADE] rounded font-['Poppins'] text-xs text-[#262626]">
                  {emailSubject}
                </div>
              </div>

              {/* Email content */}
              <div className="mt-4">
                <div className="flex items-center gap-1">
                  <span className="font-['Poppins'] text-xs text-[#262626] uppercase">Mail content</span>
                  <span className="text-[#F87171]">*</span>
                </div>
                
                {/* Toolbar */}
                <div className="border border-[#D9DADE] rounded bg-white mt-2">
                  <div className="flex items-center p-2 gap-3 border-b border-[#D9DADE] flex-wrap">
                    {/* Undo/Redo */}
                    <div className="flex gap-0.5">
                      <div className="p-1 rounded hover:bg-gray-100 cursor-pointer">
                        <Undo className="w-5 h-5" />
                      </div>
                      <div className="p-1 rounded hover:bg-gray-100 cursor-pointer">
                        <Redo className="w-5 h-5" />
                      </div>
                    </div>
                    
                    {/* Text style */}
                    <Popover>
                      <PopoverTrigger asChild>
                        <div className="flex items-center gap-1 px-2 h-7 cursor-pointer">
                          <span className="text-xs">Normal text</span>
                          <ChevronDown className="w-4 h-4" />
                        </div>
                      </PopoverTrigger>
                      <PopoverContent className="w-48 p-1">
                        <div className="cursor-pointer p-1.5 hover:bg-gray-100 rounded text-sm">Heading 1</div>
                        <div className="cursor-pointer p-1.5 hover:bg-gray-100 rounded text-sm">Heading 2</div>
                        <div className="cursor-pointer p-1.5 hover:bg-gray-100 rounded text-sm">Paragraph</div>
                      </PopoverContent>
                    </Popover>
                    
                    {/* Alignment */}
                    <Popover>
                      <PopoverTrigger asChild>
                        <div className="flex items-center gap-1 px-2 h-7 cursor-pointer">
                          <AlignLeft className="w-5 h-5" />
                          <ChevronDown className="w-4 h-4" />
                        </div>
                      </PopoverTrigger>
                      <PopoverContent className="w-40 p-1">
                        <div className="cursor-pointer p-1.5 hover:bg-gray-100 rounded text-sm flex items-center gap-2">
                          <AlignLeft className="w-4 h-4" /> Left
                        </div>
                        <div className="cursor-pointer p-1.5 hover:bg-gray-100 rounded text-sm flex items-center gap-2">
                          <AlignCenter className="w-4 h-4" /> Center
                        </div>
                        <div className="cursor-pointer p-1.5 hover:bg-gray-100 rounded text-sm flex items-center gap-2">
                          <AlignRight className="w-4 h-4" /> Right
                        </div>
                      </PopoverContent>
                    </Popover>
                    
                    {/* Color */}
                    <Popover>
                      <PopoverTrigger asChild>
                        <div className="flex items-center gap-1 px-2 h-7 cursor-pointer">
                          <div className="w-5 h-5 rounded bg-[#212529] border border-black/70"></div>
                          <ChevronDown className="w-4 h-4" />
                        </div>
                      </PopoverTrigger>
                      <PopoverContent className="w-48 p-1">
                        <div className="flex flex-wrap gap-1 p-1">
                          {['#000000', '#FF0000', '#00FF00', '#0000FF', '#FFFF00', '#00FFFF', '#FF00FF', '#C0C0C0'].map(color => (
                            <div 
                              key={color} 
                              className="w-6 h-6 rounded cursor-pointer border border-gray-300"
                              style={{ backgroundColor: color }}
                            ></div>
                          ))}
                        </div>
                      </PopoverContent>
                    </Popover>
                    
                    {/* Text formatting */}
                    <div className="flex gap-0.5">
                      <div className="p-1 rounded hover:bg-gray-100 cursor-pointer">
                        <Bold className="w-5 h-5" />
                      </div>
                      <div className="p-1 rounded hover:bg-gray-100 cursor-pointer">
                        <Italic className="w-5 h-5" />
                      </div>
                      <div className="p-1 rounded hover:bg-gray-100 cursor-pointer">
                        <Underline className="w-5 h-5" />
                      </div>
                      <div className="p-1 rounded hover:bg-gray-100 cursor-pointer">
                        <Strikethrough className="w-5 h-5" />
                      </div>
                    </div>
                    
                    {/* Lists */}
                    <div className="flex gap-0.5">
                      <div className="p-1 rounded hover:bg-gray-100 cursor-pointer">
                        <List className="w-5 h-5" />
                      </div>
                      <div className="p-1 rounded hover:bg-gray-100 cursor-pointer">
                        <ListOrdered className="w-5 h-5" />
                      </div>
                    </div>
                    
                    <div className="text-xs cursor-pointer ml-auto">Reset to default</div>
                  </div>
                  
                  {/* Editor content */}
                  <div className="p-4 font-['Poppins'] text-xs leading-relaxed text-[#262626] min-h-[200px] whitespace-pre-line">
                    {emailContent}
                  </div>
                </div>
              </div>
              
              {/* Help section */}
              <div className="flex items-center gap-1.5 mt-4">
                <ExternalLink className="w-3 h-3 text-indigo-500" />
                <span className="text-indigo-500 font-['Poppins'] text-xs flex-1">How can I change the email template?</span>
                <span className="font-['Poppins'] text-xs text-[#262626]">363/500</span>
              </div>
              
              {/* Divider */}
              <div className="h-0.5 bg-[rgba(3,2,41,0.05)] my-6"></div>
              
              {/* Alert */}
              <div className="flex items-center gap-2 p-1.5 px-4 bg-[#FEE2E2] rounded-lg">
                <AlertCircle className="w-4 h-4 text-red-600" />
                <span className="font-['Poppins'] text-xs text-[#281C37]">
                  Be careful with changing the variables, feel free to contact us
                </span>
              </div>
            </div>
            
            {/* Right column - Preview */}
            <div className="w-full md:w-[370px]">
              <h3 className="font-['Poppins'] text-[15.786px] font-semibold text-[#030229] mb-2.5">Live preview</h3>
              <div className="p-6 bg-[#FAFAFA] border border-[#D9DADE] rounded-lg font-['Poppins'] text-xs leading-relaxed text-[#262626] whitespace-pre-line">
                {emailContent}
              </div>
              
              {/* Save button */}
              <div className="flex justify-end mt-4">
                <Button 
                  className="bg-indigo-500 hover:bg-indigo-600 text-white font-medium px-8"
                  onClick={handleSave}
                >
                  Save
                </Button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default EmailEditorModal;
