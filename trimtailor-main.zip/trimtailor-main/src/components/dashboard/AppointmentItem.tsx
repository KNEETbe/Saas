
import React from 'react';

interface AppointmentItemProps {
  startTime: string;
  endTime: string;
  clientName: string;
  serviceType: string;
}

const AppointmentItem: React.FC<AppointmentItemProps> = ({ 
  startTime, 
  endTime, 
  clientName, 
  serviceType 
}) => {
  return (
    <div className="flex gap-6 p-0 px-6">
      <div className="flex items-center gap-2 text-[#6b7280]">
        <div className="flex px-2 py-0.5 text-xs border border-[rgba(38,38,38,0.5)] rounded-full">
          {startTime}
        </div>
        <div className="text-[rgba(38,38,38,0.5)]">-</div>
        <div className="flex px-2 py-0.5 text-xs border border-[rgba(38,38,38,0.5)] rounded-full">
          {endTime}
        </div>
      </div>
      
      <div className="flex flex-col">
        <div className="font-medium text-black text-sm">{clientName}</div>
        <div className="text-xs font-light text-black">{serviceType}</div>
      </div>
    </div>
  );
};

export default AppointmentItem;
