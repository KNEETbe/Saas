
import React from 'react';
import { Link } from 'react-router-dom';

interface NavItemProps {
  icon: React.ReactNode;
  text: string;
  active?: boolean;
  to: string;
}

const NavItem: React.FC<NavItemProps> = ({ icon, text, active = false, to }) => {
  return (
    <Link to={to} className="text-decoration-none">
      <div 
        className={`flex items-center px-2 py-2 cursor-pointer gap-3 
          ${active ? 'bg-[#f9fafb] text-[#312E81]' : 'text-[#262626] hover:bg-[#f9fafb]'}`}
      >
        <div className="text-[#312E81] text-[20px]">{icon}</div>
        <div className="text-sm">{text}</div>
      </div>
    </Link>
  );
};

export default NavItem;
