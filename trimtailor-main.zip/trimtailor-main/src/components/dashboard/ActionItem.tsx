
import React from 'react';

interface ActionItemProps {
  icon: React.ReactNode;
  text: string;
  shortcut: string;
}

const ActionItem: React.FC<ActionItemProps> = ({ icon, text, shortcut }) => {
  return (
    <div className="flex items-center p-4 bg-white rounded-lg cursor-pointer mb-5 relative">
      <div className="relative mr-8">
        <div className="absolute -left-4 -top-4 w-[41px] h-[41px] rounded-full bg-[#C7D2FE] bg-opacity-30 flex items-center justify-center">
          <div className="text-[#312E81]">{icon}</div>
        </div>
      </div>
      <div className="flex-grow">
        <div className="text-sm font-medium text-black">{text}</div>
      </div>
      <div className="text-xs font-light text-black">{shortcut}</div>
    </div>
  );
};

export default ActionItem;
