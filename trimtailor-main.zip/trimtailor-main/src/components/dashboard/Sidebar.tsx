
import { useState } from "react";
import { 
  Home, 
  Calendar, 
  Users, 
  MessageSquare, 
  Package, 
  FileText, 
  BarChart3,
  Settings,
  ChevronLeft,
  ChevronRight
} from "lucide-react";
import NavItem from "./NavItem";
import SettingsSidebar from "./SettingsSidebar";
import { useLocation, useNavigate } from "react-router-dom";

const Sidebar = () => {
  const [showSettings, setShowSettings] = useState(false);
  const [collapsed, setCollapsed] = useState(false);
  const location = useLocation();
  const navigate = useNavigate();

  const toggleSettings = () => {
    setShowSettings(!showSettings);
  };

  const toggleCollapse = () => {
    setCollapsed(!collapsed);
  };

  const handleProfileClick = () => {
    navigate("/profile");
  };

  // If settings sidebar is shown, render it instead of the main sidebar
  if (showSettings) {
    return <SettingsSidebar onBack={() => setShowSettings(false)} />;
  }

  // Check if the current path is the VAT rates page
  const isVatRatesPage = location.pathname.includes('/vat-rates');

  return (
    <div className={`${collapsed ? 'w-[70px]' : 'w-[193px]'} bg-[#FAFAFA] flex flex-col border-r border-[#FAFAFA] h-screen transition-all duration-300 relative font-['Poppins',sans-serif] fixed z-50`}>
      <div className="px-[29px] py-[27px] h-[42px] flex justify-center">
        {!collapsed && (
          <img 
            src="/lovable-uploads/c59ef76c-a67e-4043-8099-df183e8cc2a0.png" 
            alt="TrimTailor Logo" 
            className="h-[35px] object-contain"
          />
        )}
        {collapsed && (
          <svg width="30" height="30" viewBox="0 0 40 31" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M20.3447 14.1279C21.5914 14.1279 22.602 13.1173 22.602 11.8706C22.602 10.6239 21.5914 9.61328 18.0874 11.8706C18.0874 13.1173 19.098 14.1279 20.3447 14.1279Z" fill="#FACC15"/>
          </svg>
        )}
      </div>
      
      <div className="flex flex-col p-2 gap-2">
        <NavItem 
          icon={<Home size={20} />} 
          text={collapsed ? "" : "Home"} 
          active={location.pathname === '/dashboard'} 
          to="/dashboard"
        />
        <NavItem 
          icon={<Calendar size={20} />} 
          text={collapsed ? "" : "Calendar"} 
          active={false}
          to="#"
        />
        <NavItem 
          icon={<Users size={20} />} 
          text={collapsed ? "" : "Customers"} 
          active={false}
          to="#"
        />
        <NavItem 
          icon={<MessageSquare size={20} />} 
          text={collapsed ? "" : "Communication"} 
          active={false}
          to="#"
        />
        <NavItem 
          icon={<Package size={20} />} 
          text={collapsed ? "" : "Products"} 
          active={false}
          to="#"
        />
        <NavItem 
          icon={<FileText size={20} />} 
          text={collapsed ? "" : "Invoicing"} 
          active={false}
          to="#"
        />
        <NavItem 
          icon={<BarChart3 size={20} />} 
          text={collapsed ? "" : "Reports"} 
          active={false}
          to="#"
        />
      </div>
      
      {/* Settings button */}
      <div 
        className={`mx-3 mt-auto mb-5 flex items-center ${collapsed ? 'justify-center' : 'gap-2'} p-2 rounded-md border-2 border-[rgba(253,224,71,0.3)] bg-[#FDE047] cursor-pointer`}
        onClick={toggleSettings}
      >
        <div className="text-[#312E81] text-[20px]">
          <Settings size={20} />
        </div>
        {!collapsed && <div className="text-sm text-[#262626]">Settings</div>}
      </div>

      {/* User profile */}
      <div 
        className={`mx-[10px] mb-[20px] flex items-center ${collapsed ? 'justify-center' : 'gap-2'} p-2 border border-[#D9DADE] rounded-[3px] bg-white cursor-pointer`}
        onClick={handleProfileClick}
      >
        <div className="w-[31px] h-[30px] rounded-[8px] overflow-hidden bg-[#e0e0e0]">
          <img 
            src="https://placehold.co/32x32/e0e0e0/e0e0e0" 
            alt="Profile" 
            className="w-full h-full object-cover"
          />
        </div>
        {!collapsed && (
          <>
            <div className="flex flex-col">
              <div className="text-[11px] font-semibold text-[#262626]">Naam</div>
              <div className="text-[8px] text-[#262626]">test@trimtailor.be</div>
            </div>
            <ChevronRight className="text-[#262626] ml-auto" size={14} />
          </>
        )}
      </div>

      {/* Collapse button */}
      <div 
        className={`absolute ${collapsed ? 'left-[70px]' : 'left-[193px]'} top-[517px] h-[56px] w-[17px] bg-[#FAFAFA] rounded-r-lg flex items-center justify-center cursor-pointer border border-[#9A98A1] border-l-0`}
        onClick={toggleCollapse}
      >
        {collapsed ? (
          <ChevronRight size={14} className="text-[#312E81]" />
        ) : (
          <ChevronLeft size={14} className="text-[#312E81]" />
        )}
      </div>
    </div>
  );
};

export default Sidebar;
