
import React from 'react';
import { Search, ChevronUp, UserPlus, MessageCircle, Settings } from "lucide-react";
import AppointmentItem from './AppointmentItem';
import ActionItem from './ActionItem';

interface MainContentProps {
  salonName: string;
  appointmentsCount: number;
}

const MainContent: React.FC<MainContentProps> = ({ salonName, appointmentsCount }) => {
  return (
    <div className="flex-grow p-5 font-['Poppins',sans-serif]">
      {/* Header */}
      <div className="flex justify-between items-center mb-6 sm:flex-col sm:items-start sm:gap-4">
        <div className="text-2xl font-semibold text-[#111827]">
          Goodmorning {salonName}
        </div>
        
        <div className="flex items-center gap-4 sm:w-full">
          <div className="flex items-center bg-white border border-[#e5e7eb] rounded-lg px-4 py-2 sm:w-full">
            <Search className="text-[#6b7280] mr-2" size={16} />
            <input 
              type="text" 
              placeholder="Search customer" 
              className="border-none outline-none text-sm w-50 sm:w-full"
            />
          </div>
          
          <div className="text-sm text-[#6b7280] cursor-pointer">
            Scherminstellingen
          </div>
        </div>
      </div>
      
      {/* Content */}
      <div className="flex gap-6 md:flex-col sm:gap-4">
        {/* Appointments Column */}
        <div className="w-[388px] md:w-full">
          <div className="flex justify-between items-center mb-2.5">
            <div className="text-sm font-bold text-[#030229]">Schedule</div>
            <ChevronUp size={12} className="text-[#030229]" />
          </div>
          
          <div className="bg-[#FAFAFA] rounded-lg p-4 flex flex-col">
            <AppointmentItem 
              startTime="13:00" 
              endTime="14:00" 
              clientName="Ilse Aernouts" 
              serviceType="Kappersbeurt hond" 
            />
            
            <div className="w-full h-[0.5px] bg-[#D9DADE] my-2.5"></div>
            
            <AppointmentItem 
              startTime="14:00" 
              endTime="15:00" 
              clientName="Ronald Wierveld" 
              serviceType="Kappersbeurt hond" 
            />
            
            <div className="w-full h-[0.5px] bg-[#D9DADE] my-2.5"></div>
            
            <AppointmentItem 
              startTime="15:00" 
              endTime="16:00" 
              clientName="Pim Maes" 
              serviceType="Kappersbeurt hond" 
            />
            
            <div className="w-full h-[0.5px] bg-[#D9DADE] my-2.5"></div>
            
            <AppointmentItem 
              startTime="16:00" 
              endTime="17:00" 
              clientName="Dries Opbroeck" 
              serviceType="Kappersbeurt hond" 
            />
          </div>
        </div>
        
        {/* Quick Actions Column */}
        <div className="flex-1">
          <div className="flex justify-between items-center mb-2.5">
            <div className="text-sm font-bold text-[#030229]">Quick actions</div>
            <ChevronUp size={12} className="text-[#030229]" />
          </div>
          
          <div className="bg-[#FAFAFA] rounded-lg p-7 flex flex-col">
            <ActionItem 
              icon={<UserPlus size={16} />} 
              text="Add new customer" 
              shortcut="XX" 
            />
            
            <ActionItem 
              icon={<Settings size={16} />} 
              text="Add new tool" 
              shortcut="XX" 
            />
            
            <ActionItem 
              icon={<MessageCircle size={16} />} 
              text="Go to SMS Settings" 
              shortcut="XX" 
            />
          </div>
        </div>
      </div>
    </div>
  );
};

export default MainContent;
