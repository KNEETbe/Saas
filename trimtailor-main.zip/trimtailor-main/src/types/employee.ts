
export interface Category {
  id?: string;
  name: string;
  color: string;
  borderColor?: string;
  backgroundColor?: string;
  iconName?: string;
}

export interface Employee {
  id: string;
  name: string;
  position: string;
  email: string;
  phone: string;
  gender?: string;
  color?: string;
  image?: string;
  initials?: string;
  categories?: Category[];
  additionalCategories?: number;
  useColorInCalendar?: boolean;
  allowOnlineBooking?: boolean;
  manuallyManageTimetable?: boolean;
  categoryColor?: string;
}

// Interface for employee data received from form
export interface EmployeeFormData extends Omit<Employee, 'id'> {
  selectedCategories?: string[];
  categoryColor?: string;
}

// Alias EmployeeData to EmployeeFormData for consistency
export type EmployeeData = EmployeeFormData;
