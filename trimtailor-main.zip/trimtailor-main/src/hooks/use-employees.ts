
import { useState } from 'react';
import { Employee } from '@/types/employee';
import { initialEmployees } from '@/data/initial-employees';
import { serviceCategories } from '@/data/employee-categories';
import { useEmployeeActions } from '@/hooks/employee/use-employee-actions';

export const useEmployees = () => {
  const [employees, setEmployees] = useState<Employee[]>(initialEmployees);
  const { 
    activeDropdown, 
    handleAddEmployee, 
    handleUpdateEmployee,
    handleDeleteEmployee, 
    handleDropdownToggle 
  } = useEmployeeActions(employees, setEmployees);

  return {
    employees,
    activeDropdown,
    serviceCategories,
    handleAddEmployee,
    handleUpdateEmployee,
    handleDeleteEmployee,
    handleDropdownToggle
  };
};
