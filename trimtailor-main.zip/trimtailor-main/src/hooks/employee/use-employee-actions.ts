
import { useState } from 'react';
import { Employee, EmployeeFormData } from '@/types/employee';
import { useToast } from '@/hooks/use-toast';
import { colorLabels, serviceCategories } from '@/data/employee-categories';

export const useEmployeeActions = (employees: Employee[], setEmployees: React.Dispatch<React.SetStateAction<Employee[]>>) => {
  const [activeDropdown, setActiveDropdown] = useState<string | null>(null);
  const { toast } = useToast();

  const handleAddEmployee = (employee: EmployeeFormData) => {
    const colorLabel = colorLabels[employee.categoryColor || "#0EA5E9"] || "Categorie";
    
    // Transform selected categories into category objects
    const employeeCategories = (employee.selectedCategories || []).map(catId => {
      const category = serviceCategories.find(cat => cat.id === catId);
      if (category) {
        return {
          name: category.name,
          color: category.color,
          borderColor: category.borderColor,
          backgroundColor: category.backgroundColor,
          iconName: category.iconName
        };
      }
      return { name: "Service", color: "#0EA5E9" };
    });
    
    // If no categories were selected, add at least the main category
    const categories = employeeCategories.length > 0 
      ? employeeCategories 
      : [{ name: `Service`, color: "white", backgroundColor: employee.categoryColor || "#0EA5E9" }];
    
    const newEmployee = {
      ...employee,
      id: Date.now().toString(),
      name: employee.name || `Employee #${employees.length + 1}`,
      position: employee.position || 'Employee',
      categories
    };
    
    setEmployees([...employees, newEmployee]);
    toast({
      title: "Success",
      description: "Employee added",
    });
  };

  const handleUpdateEmployee = (id: string, updatedData: EmployeeFormData) => {
    // Transform selected categories into category objects
    const employeeCategories = (updatedData.selectedCategories || []).map(catId => {
      const category = serviceCategories.find(cat => cat.id === catId);
      if (category) {
        return {
          name: category.name,
          color: category.color,
          borderColor: category.borderColor,
          backgroundColor: category.backgroundColor,
          iconName: category.iconName
        };
      }
      return { name: "Service", color: "#0EA5E9" };
    });
    
    // If no categories were selected, add at least the main category
    const categories = employeeCategories.length > 0 
      ? employeeCategories 
      : [{ name: `Service`, color: "white", backgroundColor: updatedData.categoryColor || "#0EA5E9" }];
    
    setEmployees(employees.map(emp => 
      emp.id === id 
        ? { ...emp, ...updatedData, categories }
        : emp
    ));
    
    toast({
      title: "Success",
      description: "Employee updated",
    });
  };

  const handleDeleteEmployee = (id: string) => {
    setEmployees(employees.filter(emp => emp.id !== id));
    setActiveDropdown(null);
    toast({
      title: "Success",
      description: "Employee deleted",
    });
  };

  const handleDropdownToggle = (id: string) => {
    setActiveDropdown(activeDropdown === id ? null : id);
  };

  return {
    activeDropdown,
    handleAddEmployee,
    handleUpdateEmployee,
    handleDeleteEmployee,
    handleDropdownToggle
  };
};
